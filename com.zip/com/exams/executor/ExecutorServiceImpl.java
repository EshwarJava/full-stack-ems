package com.exams.executor;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



class Service implements Runnable{
	int i;
	Service(int i){
		this.i = i;
	}
	@Override
	public void run() {
	System.out.println(i);
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	}
}

public class ExecutorServiceImpl {

	public static void main(String[] args) throws InterruptedException {
		 ExecutorService executorService = Executors.newFixedThreadPool(6);
	        // Submit tasks for execution
	        for (int i = 0; i < 5; i++) {
	            executorService.submit(() -> System.out.println("Task executed by thread: " + Thread.currentThread().getName()));
	        }
	        executorService.shutdown();
}
}
