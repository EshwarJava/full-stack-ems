package com.exams;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class RansomNoteProblemHashMap {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String ransomNote = sc.nextLine();
		String magazine = sc.nextLine();
		System.out.println(canConstruct(ransomNote, magazine));
	}

	private static boolean canConstruct(String ransomNote, String magazine) {
		Map<Character, Integer> charMap = new HashMap<Character, Integer>();
		for (char character : ransomNote.toCharArray()) {
			if (charMap.containsKey(character)) {
				int num = charMap.get(character);
				charMap.put(character, num + 1);
			} else {
				charMap.put(character, 1);
			}
		}
		for (char magChar : magazine.toCharArray()) {
			
			if(charMap.containsKey(magChar)) {
				int num = charMap.get(magChar);
				charMap.put(magChar, num-1);
				if(charMap.get(magChar)<=0) {
					charMap.remove(magChar);
				}
			}
		}
		return charMap.isEmpty();
	}

}
