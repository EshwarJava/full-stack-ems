package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.entity.UserLeadBO;
import com.peopletech.fractionable.repository.MyTeamRepository;
import com.peopletech.fractionable.service.MyTeamService;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MyTeamServiceImpl implements MyTeamService {

    @Autowired
    MyTeamRepository myTeamRepository;

    @Autowired
    DozerBeanMapper mapper;

    @Override
    public void addMyTeam(List<Integer> userList, Integer leadId) {

        List<UserLeadBO> list =
                userList.stream().map(item -> UserLeadBO.builder().lead(UserDetailsBO.builder().id(leadId).build())
                        .user(UserDetailsBO.builder().id(item).build()).build()
                ).toList();
        myTeamRepository.saveAll(list);
    }

    @Override
    public List<UserDetailsDto> getMyTeam(Integer leadId) {

        Collection<UserLeadBO> userLeadBOS = myTeamRepository.findByLeadId(leadId);
        return userLeadBOS.stream().map(userLead ->
                mapper.map(userLead.getUser(), UserDetailsDto.class)).collect(Collectors.toList());
    }

    @Override
    public void removeFromMyTeam(Integer userId, Integer leadId) {
        myTeamRepository.delete(UserLeadBO.builder().user(UserDetailsBO.builder().id(userId).build())
                .lead(UserDetailsBO.builder().id(leadId).build()).build());
    }
}
