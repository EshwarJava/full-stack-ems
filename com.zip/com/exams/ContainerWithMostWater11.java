package com.exams;

public class ContainerWithMostWater11 {

	public static void main(String[] args) {
		
		int[] heightArr = new int[] { 1, 5, 9, 1, 5, 9};
		System.out.println(maxArea(heightArr));

	}
	private static int maxArea(int[] heightArr) {
		int max = 0;
		int i =0;
		int j = heightArr.length-1;
		while(i<j) {
			int area = Math.min(heightArr[i],heightArr[j])*(j-i);
			max = Math.max(max, area);
			if(heightArr[i]<heightArr[j]) {
				i++;
			}else {
				j--;
			}
		}
		return max;
	}

}
