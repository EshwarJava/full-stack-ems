package com.peopletech.fractionable.converter;

import com.peopletech.fractionable.entity.UserDetailsBO;
import org.dozer.CustomConverter;

public class UserDetailsDozerConverter implements CustomConverter {

    @Override
    public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
        UserDetailsBO userDetails = (UserDetailsBO) source;
        return userDetails.getFirstName().concat(" ").concat(userDetails.getLastName());
    }
}