package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.*;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.CandidateDetailsDeleteRequest;
import com.peopletech.fractionable.dto.request.CandidateRejectOrCallbackRequest;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.entity.compoundkey.SjdCandidateInfoId;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.service.CandidateService;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.service.SjdService;
import com.peopletech.fractionable.specifications.CandidateSpecifications;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.transaction.Transactional;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

@Service
public class CandidateServiceImpl implements CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private SjdRepository sjdRepository;

    @Autowired
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Autowired
    private CandidateDocumentRepository candidateDocumentRepository;

    @Autowired
    private CandidateEventService candidateEventService;

    @Autowired
    private SjdService sjdService;

    @Autowired
    private CandidateEventRepository candidateEventRepository;

    @Autowired
    private CandidateInterviewRepository candidateInterviewRepository;

    @Autowired
    private CandidateSkillMappingRepository candidateSkillMappingRepository;

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Autowired
    private LookupService lookupService;

    @Autowired
    private CommonUtil commonUtil;

    @Autowired
    private CandidateEmploymentRepository candidateEmploymentRepository;

    @Autowired
    private CandidateEducationRepository candidateEducationRepository;

    @Autowired
    private CandidateCertificationRepository candidateCertificationRepository;

    @Autowired
    private DozerBeanMapper mapper;

    @Value("${fractionable.minimum.rating}")
    private Float minimumRating;


    @Override
    public CandidateDto getCandidateById(Integer candidateId, Integer sjdId) {
        CandidateBO candidateBO = candidateRepository
                .findById(candidateId)
                .orElseThrow(() -> new NoSuchElementException(String.format("The requested candidate with id %s is not found", candidateId)));
        CandidateDto candidateDto = mapper.map(candidateBO, CandidateDto.class);
        if (sjdId != null) {

            List<CandidateInterviewBO> candidateInterview = candidateInterviewRepository.findBySjdIdAndCandidateId(sjdId, candidateId);

            List<CandidateInterviewDto> interviewDtos = candidateInterview.stream().map(interview -> {
                CandidateInterviewDto dto = mapper.map(interview, CandidateInterviewDto.class);
                dto.setEvaluator(
                        mapper.map(userDetailsRepository.findById(interview.getEvaluatorId()).get(), UserDetailsDto.class)
                );
                return dto;
            }).toList();

            candidateDto.setInterview(interviewDtos);
            List<CandidateEventDto> candidateEvents = commonUtil.mapList(
                    candidateEventRepository
                            .findBySjdIdAndCandidateIdOrderByCreatedOnDesc(sjdId, candidateId),
                    CandidateEventDto.class);
            candidateDto.setEvents(candidateEvents);
        }
        return candidateDto;
    }

    @Override
    public List<CandidateDto> getCandidateBySjdId(Integer sjdId) {
        List<SjdCandidateInfoBO> candidates = sjdCandidateInfoRepository.findBySjdId(sjdId);
        return candidates
                .stream()
                .map(c -> mapper.map(c.getCandidate(), CandidateDto.class))
                .toList();
    }

    @Override
    public List<CandidateDto> getAllCandidates() {
        Iterable<CandidateBO> itr = candidateRepository.findAll();
        return StreamSupport
                .stream(itr.spliterator(), false)
                .map(bo -> mapper.map(bo, CandidateDto.class))
                .toList();
    }

    @Override
    @Transactional
    public Integer saveCandidate(CandidateDto candidate, Integer sjdId, Integer userId) {

        List<String> allSkills = lookupService.getSkills().stream().map(s -> s.getName().toLowerCase()).toList();

        List<SkillBO> existingSkills = new ArrayList<>();
        List<LookupDto> newSkills = new ArrayList<>();

        candidate.getSkills().stream().forEach(s -> {
            if (allSkills.contains(s.getName().toLowerCase())) {
                existingSkills.add(mapper.map(s, SkillBO.class));
            } else {
                newSkills.add(s);
            }
        });

        List<SkillBO> skills = lookupService.saveAllSkills(newSkills);
        skills.addAll(existingSkills);

        CandidateBO candidateBO = mapper.map(candidate, CandidateBO.class);
        candidateBO.setSkills(skills);
        candidateBO.setCreatedBy(userId);
        candidateBO.setCreatedOn(new Date());
        candidateBO.setModifiedBy(userId);
        candidateBO.setModifiedOn(new Date());
        CandidateBO result = candidateRepository.save(candidateBO);
        if (sjdId != null) {
            CandidateEventDto candidateEvent =
                    CandidateEventDto
                            .builder()
                            .sjdId(sjdId)
                            .candidateId(result.getId())
                            .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_CREATED.name()).getId())
                            .description(String.valueOf(result.getId()))
                            .build();
            candidateEventService.addEvent(candidateEvent, userId);

            TagCandidateRequest info = new TagCandidateRequest(sjdId, result.getId(), null);
            sjdService.tagCandidateToSjd(info, userId);
        }

        return result.getId();
    }

    @Override
    @Transactional
    public Integer updateCandidate(CandidateDto candidate, Integer sjdId, Integer userId, Boolean isResumeUpdate) {
        CandidateBO candidateBO = candidateRepository
                .findById(candidate.getId())
                .orElseThrow(() -> new NoSuchElementException(String.format("The requested candidate with id %s is not found", candidate.getId())));

        List<String> allSkills = lookupService.getSkills().stream().map(s -> s.getName().toLowerCase()).toList();

        List<SkillBO> existingSkills = new ArrayList<>();
        List<LookupDto> newSkills = new ArrayList<>();

        candidate.getSkills().stream().forEach(s -> {
            if (allSkills.contains(s.getName().toLowerCase())) {
                existingSkills.add(mapper.map(s, SkillBO.class));
            } else {
                newSkills.add(s);
            }
        });
        List<SkillBO> skills = lookupService.saveAllSkills(newSkills);
        skills.addAll(existingSkills);
/*
        List<Integer> skillsInNewObject = skills.stream().map(SkillBO::getId).toList();

        List<CandidateSkillID> skillsToBeDeleted = candidateBO.getSkills()
                .stream()
                .filter(skill -> !skillsInNewObject.contains(skill.getId()))
                .map(skill -> new CandidateSkillID(candidate.getId(), skill.getId()))
                .collect(Collectors.toList());

        candidateSkillMappingRepository.deleteAllById(skillsToBeDeleted);
*/
        mapper.map(candidate, candidateBO);
        candidateBO.setSkills(skills);
        candidateBO.setModifiedBy(userId);
        candidateBO.setModifiedOn(new Date());
        CandidateBO result = candidateRepository.save(candidateBO);
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(sjdId)
                        .candidateId(candidate.getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(
                                isResumeUpdate ? CandidateEventType.RESUME_UPDATED.name() : CandidateEventType.CANDIDATE_DETAILS_UPDATED.name()
                        ).getId())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
        return result.getId();
    }

    @Override
    public void updateCandidateStatus(CandidateStatusChangeDto request, Integer userId) {
        CandidateStatusBO status = new CandidateStatusBO();
        status.setId(request.getStatusId());
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        info.setCandidateStatus(status);
        String newStatus = commonUtil.getNameFromId(request.getStatusId(), LookupType.CANDIDATE_STATUS);
        CandidateEventType eventType = CandidateEventType.CANDIDATE_STATUS_CHANGED;
        String description = newStatus;
        if (newStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_REJECTED.getType())) {
            eventType = CandidateEventType.CANDIDATE_REJECTED;
            description = request.getReason();
        } else if (newStatus.equalsIgnoreCase(CandidateStatusType.CALLBACK.getType())) {
            eventType = CandidateEventType.CALLBACK_ADDED;
            description = request.getReason();
        }
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(eventType.name()).getId())
                        .description(description)
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
        sjdCandidateInfoRepository.save(info).getId();
    }

    @Override
    public void updateCandidateQcRating(SjdCandidateInfoDto request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        Float existingRating = info.getQcRating();
        String existingStatus = info.getCandidateStatus().getName();
        info.setQcRating(request.getQcRating());

        // For newly rated, change the status. For rating update, do not change the status.
        if (request.getQcRating() < minimumRating) {
            info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.CANDIDATE_REJECTED.getType()));
        } else if (existingRating == null || existingStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_REJECTED.getType())) {
            info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.QC_RATED.getType()));
        }
        sjdCandidateInfoRepository.save(info);

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.QC_RATING_ADDED.name()).getId())
                        .description(String.valueOf(request.getQcRating()))
                        .build();

        // Add an event for candidate rated
        candidateEventService.addEvent(candidateEvent, userId);

        // Add an event for candidate status update
        if (request.getQcRating() < minimumRating) {
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_REJECTED.name()).getId());
            candidateEvent.setDescription(RejectReasons.LOW_RATING.getType());
            candidateEventService.addEvent(candidateEvent, userId);
        } else if (existingRating == null || existingStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_REJECTED.getType())) {
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_STATUS_CHANGED.name()).getId());
            candidateEvent.setDescription(CandidateStatusType.QC_RATED.getType());
            candidateEventService.addEvent(candidateEvent, userId);
        }
    }

    @Override
    public void updateCandidateProfilerRating(SjdCandidateInfoDto request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        Float existingRating = info.getProfilerRating();
        String existingStatus = info.getCandidateStatus().getName();
        info.setProfilerRating(request.getProfilerRating());

        // For newly rated, change the status. For rating update, do not change the status.
        if (request.getProfilerRating() < minimumRating) {
            info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.CANDIDATE_REJECTED.getType()));
        } else if (existingRating == null || existingStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_REJECTED.getType())) {
            SjdDto sjd = sjdService.getSjd(request.getSjdId());
            info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.PROFILER_RATED.getType()));
        }
        sjdCandidateInfoRepository.save(info);

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.PROFILER_RATING_ADDED.name()).getId())
                        .description(String.valueOf(request.getProfilerRating()))
                        .build();

        // Add an event for candidate rated
        candidateEventService.addEvent(candidateEvent, userId);

        // Add an event for candidate status update
        if (request.getProfilerRating() < minimumRating) {
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_REJECTED.name()).getId());
            candidateEvent.setDescription(RejectReasons.LOW_RATING.getType());
            candidateEventService.addEvent(candidateEvent, userId);
        } else if (existingRating == null || existingStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_REJECTED.getType())) {
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_STATUS_CHANGED.name()).getId());
            candidateEvent.setDescription(CandidateStatusType.PROFILER_RATED.getType());
            candidateEventService.addEvent(candidateEvent, userId);
        }
    }

    @Override
    public Integer addComments(CandidateEventDto request, Integer userId) {
        request.setEventTypeId(
                commonUtil.getCandidateEventTypeId(CandidateEventType.COMMENTS_ADDED.name()).getId()
        );
        return candidateEventService.addEvent(request, userId);
    }

    @Override
    public void rejectOrCallback(CandidateRejectOrCallbackRequest request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));

        info.setCandidateStatus(commonUtil.getCandidateStatus(
                "Reject".equalsIgnoreCase(request.getType()) ? CandidateStatusType.CANDIDATE_REJECTED.getType() : CandidateStatusType.CALLBACK.getType()
        ));
        sjdCandidateInfoRepository.save(info).getId();
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(
                                "Reject".equalsIgnoreCase(request.getType()) ? CandidateEventType.CANDIDATE_REJECTED.name() : CandidateEventType.CALLBACK_ADDED.name()).getId())
                        .description(request.getReason() != null ? request.getReason() : request.getComment())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }

    @Override
    public void scheduleInterview(CandidateInterviewDto request, Integer userId) {
        CandidateInterviewBO candidateInterview = mapper.map(request, CandidateInterviewBO.class);
        candidateInterview.setEvaluatorId(request.getEvaluator().getId());
        candidateInterview.setCreatedBy(userId);
        candidateInterview.setCreatedOn(new Date());
        candidateInterview.setModifiedBy(userId);
        candidateInterview.setModifiedOn(new Date());
        candidateInterviewRepository.save(candidateInterview);
        String level = candidateInterview.getInterviewLevel();

        CandidateStatusType status = candidateInterview.getInterviewLevel().startsWith("HR") ?
                CandidateStatusType.HR_INTERVIEW_SCHEDULED : CandidateStatusType.get("Tech Interview-".concat(level.substring(level.length() - 1)).concat(" Scheduled"));
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        info.setCandidateStatus(commonUtil.getCandidateStatus(status.getType()));
        sjdCandidateInfoRepository.save(info);
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_STATUS_CHANGED.name()).getId())
                        .description(status.getType())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);

        DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat timeFormatter = new SimpleDateFormat("hh:mm a");
        candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.INTERVIEW_SCHEDULED.name()).getId());
        candidateEvent.setDescription(
                dateFormatter.format(request.getStartTime())
                        .concat(" ")
                        .concat(timeFormatter.format(request.getStartTime()))
                        .concat(" - ")
                        .concat(timeFormatter.format(request.getEndTime()))
        );
        candidateEventService.addEvent(candidateEvent, userId);
    }

    @Override
    public void updateInterviewDetails(CandidateInterviewDto request, Integer userId, Boolean isFeedback) {
        CandidateInterviewBO candidateInterview = candidateInterviewRepository
                .findById(request.getId())
                .orElseThrow(() -> new NoSuchElementException(String.format("No interview schedule exists between sjd id %s, candidate id %s and evaluator id %s", request.getSjdId(), request.getCandidateId(), request.getEvaluator().getId())));
        mapper.map(request, candidateInterview);
        candidateInterview.setEvaluatorId(request.getEvaluator().getId());
        candidateInterview.setModifiedBy(userId);
        candidateInterview.setModifiedOn(new Date());
        candidateInterviewRepository.save(candidateInterview);

        CandidateStatusType status = null;
        String description = null;
        if (isFeedback) {
            String level = candidateInterview.getInterviewLevel();
            if (level.startsWith("HR")) {
                if (candidateInterview.getIsRecommended()) {
                    status = CandidateStatusType.HR_INTERVIEW_CLEARED;
                    description = CandidateStatusType.HR_INTERVIEW_CLEARED.getType();
                } else {
                    status = CandidateStatusType.CANDIDATE_REJECTED;
                    description = RejectReasons.FAILED_IN_INTERVIEW.getType();
                }
            } else if (level.startsWith("Technical-")) {
                if (candidateInterview.getIsRecommended()) {
                    status = CandidateStatusType.get("Tech Interview-".concat(level.substring(level.length() - 1)).concat(" cleared"));
                    description = status.getType();
                } else {
                    status = CandidateStatusType.CANDIDATE_REJECTED;
                    description = RejectReasons.FAILED_IN_INTERVIEW.getType();
                }
            }

            SjdCandidateInfoBO info = sjdCandidateInfoRepository
                    .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                    .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
            info.setCandidateStatus(commonUtil.getCandidateStatus(status.getType()));
            sjdCandidateInfoRepository.save(info);

            CandidateEventDto candidateEvent =
                    CandidateEventDto
                            .builder()
                            .sjdId(info.getSjd().getId())
                            .candidateId(info.getCandidate().getId())
                            .description(description)
                            .build();
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.FEEDBACK_ADDED.name()).getId());
            candidateEventService.addEvent(candidateEvent, userId);

            if (candidateInterview.getIsRecommended()) {
                candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_STATUS_CHANGED.name()).getId());
            } else {
                candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_REJECTED.name()).getId());
            }
            candidateEventService.addEvent(candidateEvent, userId);
        } else {
            DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat timeFormatter = new SimpleDateFormat("hh:mm a");
            CandidateEventDto candidateEvent =
                    CandidateEventDto
                            .builder()
                            .sjdId(request.getSjdId())
                            .candidateId(request.getCandidateId())
                            .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.INTERVIEW_RESCHEDULED.name()).getId())
                            .description(
                                    dateFormatter.format(request.getStartTime())
                                            .concat(" ")
                                            .concat(timeFormatter.format(request.getStartTime()))
                                            .concat(" - ")
                                            .concat(timeFormatter.format(request.getEndTime()))
                            ).build();
            candidateEventService.addEvent(candidateEvent, userId);
        }
    }

    @Override
    public Integer addDocumentInformation(CandidateDocumentDto document, Integer userId) {
        CandidateDocumentBO candidateDocumentBO = mapper.map(document, CandidateDocumentBO.class);
        candidateDocumentBO.setCreatedBy(UserDetailsBO.builder().id(userId).build());
        candidateDocumentBO.setCreatedOn(new Date());
        return candidateDocumentRepository.save(candidateDocumentBO).getId();
    }

    @Override
    public List<CandidateDto> searchCandidate(String email, String phone) {
        Specification spec = null;

        if (!StringUtils.isEmpty(email) && !StringUtils.isEmpty(phone))
            spec = CandidateSpecifications.isEmailPresent(email).or(CandidateSpecifications.isPhoneNumberPresent(phone));
        else if (!StringUtils.isEmpty(email))
            spec = CandidateSpecifications.isEmailPresent(email);
        else if (!StringUtils.isEmpty(phone))
            spec = CandidateSpecifications.isPhoneNumberPresent(phone);
        List<CandidateBO> all = candidateRepository.findAll(spec);
        return commonUtil.mapList(all, CandidateDto.class);
    }

    @Override
    public void auditCandidate(SjdCandidateInfoDto request, Integer userId) {
        SjdCandidateInfoBO existing = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        existing.setAuditResult(request.getAuditResult());
        existing.setAuditComments(request.getAuditComments());
        existing.setAuditBy(UserDetailsBO.builder().id(userId).build());
        existing.setAuditOn(new Date());
        sjdCandidateInfoRepository.save(existing);
    }

    @Override
    public List<ResumeSearchResponseDto> searchCandidateFromResumeId(List<String> resumeIds) {
        List<CandidateBO> candidates = candidateRepository.findByResumeIdIn(resumeIds);
        return candidates.stream().map((candidateBO -> {
            List<SjdBO> sjdBOS = candidateBO.getSjdCandidateInfo().stream()
                    .map((sjdCandidateInfoBO -> sjdCandidateInfoBO.getSjd())).toList();
            return ResumeSearchResponseDto.builder()
                    .resumeId(candidateBO.getResumeId())
                    .candidateId(candidateBO.getId())
                    .sjds(sjdBOS.stream().map(sjdBO -> mapper.map(sjdBO, SjdDto.class)).toList()).build();
        })).toList();
    }

    @Override
    public void deleteCandidateDetails(CandidateDetailsDeleteRequest request, CandidateDetailsType type, Integer userId) {
        CandidateEventType eventType = CandidateEventType.CANDIDATE_DETAILS_UPDATED;
        switch (type) {
            case EMPLOYMENT:
                candidateEmploymentRepository.deleteById(request.getIdToBeDeleted());
                break;
            case EDUCATION:
                candidateEducationRepository.deleteById(request.getIdToBeDeleted());
                break;
            case CERTIFICATION:
                candidateCertificationRepository.deleteById(request.getIdToBeDeleted());
                break;
            case INTERVIEW:
                candidateInterviewRepository.deleteById(request.getIdToBeDeleted());
                eventType = CandidateEventType.INTERVIEW_DELETED;
                break;
        }
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(request.getSjdId())
                        .candidateId(request.getCandidateId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(eventType.name()).getId())
                        .description(String.valueOf(request.getIdToBeDeleted()))
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }
}
