package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateStatusBO;
import org.springframework.data.repository.CrudRepository;

public interface CandidateStatusRepository extends CrudRepository<CandidateStatusBO, Integer> {
}
