package com.exams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OracleProblems {

	public static void main(String[] args) {
		String s = "(name)is(age)yearsold";
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.entrySet();
		
		 for(Map.Entry<Integer, Integer> entry : map.entrySet()){
			 
	       }
		List<List<String>> l = new ArrayList<List<String>>();
		List<String> l1 = Arrays.asList("name","bob");
		List<String> l2 = Arrays.asList("age","two");
		l.add(l1);
		l.add(l2);
		
		System.out.println(replaceFew(l, s));
	}

	private static String replaceFew(List<List<String>> l, String s) {
		for (List<String> list : l) {
			String target = "(" + list.get(0) + ")";
            String replacement = list.get(1);
            s = s.replaceAll(target, replacement);
		}	
		return s;		
	}
}
