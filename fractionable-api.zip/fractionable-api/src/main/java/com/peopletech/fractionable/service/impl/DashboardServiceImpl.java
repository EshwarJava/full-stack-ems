package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.CandidateStatusType;
import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.AuditCandidatesReportDto;
import com.peopletech.fractionable.dto.InterviewReportDto;
import com.peopletech.fractionable.dto.QCRatedCandidatesReportDto;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.DashboardService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    SjdRepository sjdRepository;

    @Autowired
    SjdUserRepository sjdUserRepository;

    @Autowired
    SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Autowired
    CandidateInterviewRepository candidateInterviewRepository;

    @Autowired
    UserDetailsRepository userDetailsRepository;

    @Autowired
    CandidateRepository candidateRepository;

    @Autowired
    CommonUtil commonUtil;

    @Override
    public List<QCRatedCandidatesReportDto> getQCRatedCandidates(Integer userId) {
        List<Tuple> sjdList = userId == null ? sjdRepository.findAllSjdId()
                : sjdUserRepository.findAllSjdIdByUserId(userId);
        List<Tuple> qcRatedCandidates = sjdCandidateInfoRepository.getQCRatedCandidates(
                commonUtil.getIdFromName(CandidateStatusType.QC_RATED.getType(), LookupType.CANDIDATE_STATUS),
                sjdList.stream().map(s -> s.get(0, Integer.class)).toList()
        );
        return qcRatedCandidates.stream().map(result -> mapTupleToQCRatedCandidatesReportDto(result)).toList();
    }

    private QCRatedCandidatesReportDto mapTupleToQCRatedCandidatesReportDto(Tuple result) {
        QCRatedCandidatesReportDto reportDto = new QCRatedCandidatesReportDto();
        reportDto.setCandidateId(result.get(0, Integer.class));
        reportDto.setCandidateName(result.get(1, String.class));
        reportDto.setSjdId(result.get(2, Integer.class));
        reportDto.setSjdName(result.get(3, String.class));
        if (result.get(4) != null) {
            reportDto.setQcRating(result.get(4, BigDecimal.class).floatValue());
        }
        reportDto.setRecruiterId(result.get(5, Integer.class));
        reportDto.setRecruiterName(result.get(6, String.class));
        return reportDto;
    }

    @Override
    public List<InterviewReportDto> getActiveInterviews(Integer userId) {
        List<Tuple> sjdList = userId == null ? sjdRepository.findAllSjdId()
                : sjdUserRepository.findAllSjdIdByUserId(userId);
        List<Tuple> qcRatedCandidates = candidateInterviewRepository.getActiveInterviews(sjdList.stream().map(s -> s.get(0, Integer.class)).toList());
        List<InterviewReportDto> dtos = qcRatedCandidates.stream().map(result -> mapTupleToActiveInterviewsReportDto(result)).toList();
        List<Tuple> userNames = userDetailsRepository.getUserNameFromId(dtos.stream().map(d -> d.getCreatedById()).toList());
        Map<Integer, String> users = userNames.stream().collect(Collectors.toMap(user -> user.get(0, Integer.class), user -> user.get(1, String.class)));
        dtos.stream().forEach(d -> d.setCreatedByName(users.get(d.getCreatedById())));
        return dtos;
    }

    @Override
    public List<InterviewReportDto> getMyInterviews(Integer userId) {
        List<Tuple> myInterviews = candidateInterviewRepository.getMyInterviews(userId);
        return myInterviews.stream().map(result -> mapTupleToMyInterviewsReportDto(result)).toList();
    }


    private InterviewReportDto mapTupleToActiveInterviewsReportDto(Tuple result) {
        InterviewReportDto reportDto = new InterviewReportDto();
        reportDto.setCandidateId(result.get(0, Integer.class));
        reportDto.setCandidateName(result.get(1, String.class));
        reportDto.setSjdId(result.get(2, Integer.class));
        reportDto.setSjdName(result.get(3, String.class));
        reportDto.setInterviewLevel(result.get(4, String.class));
        reportDto.setEvaluatorId(result.get(5, Integer.class));
        reportDto.setEvaluatorName(result.get(6, String.class));
        reportDto.setStartDate(Date.from(result.get(7, Instant.class)));
        reportDto.setEndDate(Date.from(result.get(8, Instant.class)));
        reportDto.setCreatedById(result.get(9, Integer.class));
        return reportDto;
    }

    private InterviewReportDto mapTupleToMyInterviewsReportDto(Tuple result) {
        InterviewReportDto reportDto = new InterviewReportDto();
        reportDto.setCandidateId(result.get(0, Integer.class));
        reportDto.setCandidateName(result.get(1, String.class));
        reportDto.setSjdId(result.get(2, Integer.class));
        reportDto.setSjdName(result.get(3, String.class));
        reportDto.setInterviewLevel(result.get(4, String.class));
        reportDto.setStartDate(Date.from(result.get(5, Instant.class)));
        reportDto.setEndDate(Date.from(result.get(6, Instant.class)));
        reportDto.setCreatedById(result.get(7, Integer.class));
        reportDto.setCreatedByName(result.get(8, String.class));
        reportDto.setInterviewResult(result.get(9, Boolean.class));
        return reportDto;
    }

    @Override
    public Map<Integer, Long> getCandidateCountBySourceChannel() {
        List<Tuple> candidateCountBySourceChannel = candidateRepository.getCandidateCountBySourceChannel();
        return candidateCountBySourceChannel.stream().collect(Collectors.toMap(c -> c.get(0, Integer.class), c -> c.get(1, Long.class)));
    }

    @Override
    public Map<String, Long> getCandidateCountByStatus(Integer userId, String fromDate, String toDate) throws ParseException {
        List<Tuple> sjdList = userId == null ? sjdRepository.findAllSjdId()
                : sjdUserRepository.findAllSjdIdByUserId(userId);
        List<Integer> sjdIds = sjdList.stream().map(s -> s.get(0, Integer.class)).toList();
        List<Tuple> candidateCountByStatus;
        if (fromDate != null && toDate != null) {
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'+'SSSS");
            Calendar from = Calendar.getInstance();
            from.setTime(formatter.parse(fromDate));
            from.set(from.get(Calendar.YEAR), from.get(Calendar.MONTH), from.get(Calendar.DATE), 0, 0, 0);

            Calendar to = Calendar.getInstance();
            to.setTime(formatter.parse(toDate));
            to.set(from.get(Calendar.YEAR), from.get(Calendar.MONTH), from.get(Calendar.DATE), 23, 59, 59);

            candidateCountByStatus = candidateRepository.filterCandidateCountByStatus(
                    sjdIds,
                    from.getTime(),
                    to.getTime());
        } else {
            candidateCountByStatus = candidateRepository.getCandidateCountByStatus(sjdIds);
        }
        return candidateCountByStatus.stream().collect(Collectors.toMap(c -> c.get(0, String.class), c -> c.get(1, Long.class)));
    }

    @Override
    public Map<String, Long> getSjdCountByStatus(Integer userId) {
        List<Tuple> sjdList = userId == null ? sjdRepository.findAllSjdId()
                : sjdUserRepository.findAllSjdIdByUserId(userId);
        List<Tuple> candidateCountByStatus = sjdRepository.getSjdCountByStatus(sjdList.stream().map(s -> s.get(0, Integer.class)).toList());
        return candidateCountByStatus.stream().collect(Collectors.toMap(c -> c.get(0, String.class), c -> c.get(1, Long.class)));
    }

    @Override
    public List<AuditCandidatesReportDto> getAuditCandidates(String fromDate, String toDate) throws ParseException {
        List<Tuple> result;
        Calendar cal = Calendar.getInstance();
        if (fromDate != null && toDate != null) {
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'+'SSSS");
            cal.setTime(formatter.parse(toDate));
            cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE), 23, 59, 59);
            result = sjdCandidateInfoRepository.filterAuditCandidates(formatter.parse(fromDate), cal.getTime());
        } else {
            result = sjdCandidateInfoRepository.findAuditCandidates();
        }
        return result.stream().map(this::mapToAuditCandidatesReportDto).toList();
    }

    private AuditCandidatesReportDto mapToAuditCandidatesReportDto(Tuple tuple) {
        AuditCandidatesReportDto report = new AuditCandidatesReportDto();
        report.setSjdId(tuple.get(0, Integer.class));
        report.setSjdName(tuple.get(1, String.class));
        report.setCandidateId(tuple.get(2, Integer.class));
        report.setCandidateName(tuple.get(3, String.class));
        report.setRecruiterId(tuple.get(4, Integer.class));
        report.setRecruiterName(tuple.get(5, String.class));
        report.setCreatedOn(Date.from(tuple.get(6, Instant.class)));
        return report;
    }

    @Override
    public List<Map<String, Object>> getSourcingTrends(Integer count) {
        List<Tuple> auditResult = sjdCandidateInfoRepository.getAuditTrends(count);
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Map<String, Long> audit = new HashMap<>();
        auditResult.stream().forEach(r -> {
            audit.put(
                    formatter.format(r.get(0, java.sql.Date.class)),
                    r.get(1, Long.class)
            );
        });

        List<Tuple> result = sjdCandidateInfoRepository.getSourcingTrends(count);
        List<Map<String, Object>> trend = new ArrayList<>();
        result.stream().forEach(t -> {
            Map<String, Object> temp = new HashMap<>();
            String dt = formatter.format(t.get(0, java.sql.Date.class));
            temp.put("date", dt);
            temp.put("candidateCount", t.get(1, Long.class));
            temp.put("auditCount", audit.get(dt));
            trend.add(temp);
        });

        return trend;
    }

    @Override
    public List<Map<String, Object>> getRatingTrends(Integer count) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        List<Tuple> ratingResult = sjdCandidateInfoRepository.getRatingTrends(count);
        List<Map<String, Object>> rating = new ArrayList<>();

        ratingResult.stream().forEach(t -> {
            Map<String, Object> temp = new HashMap<>();
            String dt = formatter.format(t.get(0, java.sql.Date.class));
            temp.put("date", dt);
            temp.put("qcRating", roundOff(t.get(1, BigDecimal.class)));
            temp.put("profilerRating", roundOff(t.get(2, BigDecimal.class)));
            rating.add(temp);
        });

        return rating;
    }

    private BigDecimal roundOff(BigDecimal v) {
        if (v == null)
            return v;
        return v.setScale(2, RoundingMode.HALF_EVEN);
    }

}
