package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.dto.SourcerReportDto;
import com.peopletech.fractionable.dto.request.ReportRequestDto;
import com.peopletech.fractionable.entity.UserLeadBO;
import com.peopletech.fractionable.repository.CandidateEventRepository;
import com.peopletech.fractionable.repository.MyTeamRepository;
import com.peopletech.fractionable.repository.UserDetailsRepository;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.service.ReportService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SourcerReportServiceImpl implements ReportService<Map<String, List<SourcerReportDto>>, byte[]> {

    @Autowired
    CandidateEventRepository candidateEventRepository;

    @Autowired
    MyTeamRepository myTeamRepository;

    @Autowired
    UserDetailsRepository userDetailsRepository;

    @Autowired
    LookupService lookupService;

    @Autowired
    CommonUtil commonUtil;

    @Override
    public Map<String, List<SourcerReportDto>> getReport(ReportRequestDto reportRequestDto) {
        List<SourcerReportDto> list = getSourcerReportData(reportRequestDto.getUserId(), reportRequestDto.getFromDate(), reportRequestDto.getToDate(), reportRequestDto.getOperations());
        return list.stream().collect(Collectors.groupingBy(item -> item.getRecruiterName()));
    }

    @Override
    public byte[] getReportExcel(ReportRequestDto reportRequestDto) throws IOException {
        List<SourcerReportDto> list = getSourcerReportData(reportRequestDto.getUserId(), reportRequestDto.getFromDate(), reportRequestDto.getToDate(), reportRequestDto.getOperations());
        Map<String, Integer> headers = new LinkedHashMap<>();
        headers.put("SJD ID", 10);
        headers.put("SJD Name", 20);
        headers.put("Candidate Name", 30);
        headers.put("Phone", 20);
        headers.put("Email", 30);
        headers.put("Experience (years)", 20);
        headers.put("Notice Period (days)", 20);
        headers.put("QC Rating", 15);
        headers.put("Status", 50);
        headers.put("Recruiter", 30);
        headers.put("Created On", 30);
        headers.put("Operations",60);

        Workbook wb = new HSSFWorkbook();
        Sheet sheet = wb.createSheet("Report");
        int index = 0;
        for (String key : headers.keySet()) {
            sheet.setColumnWidth(index++, 256 * headers.get(key));
        }

        Row row = sheet.createRow(0);
        populateHeaderRow(wb, row, headers.keySet());
        CellStyle center = wb.createCellStyle();
        center.setAlignment(HorizontalAlignment.CENTER);
        for (int i = 0; i < list.size(); i++) {
            Row r = sheet.createRow(i + 1);
            populateDataRow(center, r, list.get(i));
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wb.write(out);
        out.close();
        wb.close();
        return out.toByteArray();
    }

    private List<SourcerReportDto> getSourcerReportData(Integer userId, Date fromDate, Date toDate, Integer operations) {
        boolean isAdmin = userDetailsRepository
                .findById(userId)
                .orElseThrow(() -> new NoSuchElementException(String.format("The requested user with id %s is not found", userId)))
                .getRoles()
                .stream()
                .anyMatch((role) -> role.getName().equalsIgnoreCase("admin"));

        Calendar from = Calendar.getInstance();
        from.setTime(fromDate);
        from.set(from.get(Calendar.YEAR), from.get(Calendar.MONTH), from.get(Calendar.DATE), 00, 00, 00);


        Calendar to = Calendar.getInstance();
        to.setTime(toDate);
        to.set(to.get(Calendar.YEAR), to.get(Calendar.MONTH), to.get(Calendar.DATE), 23, 59, 59);
        List<Integer> teamMemberIds = new ArrayList<>();
        if (!isAdmin) {
            Collection<UserLeadBO> userLeadBOS = myTeamRepository.findByLeadId(userId);
            teamMemberIds.addAll(userLeadBOS.stream().map(bo -> bo.getUser().getId()).toList());
            teamMemberIds.add(userId);
        }
        List<Integer> operationIds = operations != null ? Arrays.asList(operations) : lookupService.getLookupValues(LookupType.OPERATION).stream().map(LookupDto::getId).toList();
        List<Tuple> tupleData = isAdmin ? candidateEventRepository.findSourcerReportForAdmin(2, fromDate, to.getTime(), operationIds)
                : candidateEventRepository.findSourcerReport(2, teamMemberIds, from.getTime(), to.getTime());
        return tupleData.stream().map(tuple -> mapSourcerTupleToDto(tuple)).toList();
    }


    private SourcerReportDto mapSourcerTupleToDto(Tuple tuple) {
        SourcerReportDto dto = SourcerReportDto.builder()
                .candidateId(tuple.get(0, Integer.class))
                .sjdId(tuple.get(1, Integer.class))
                .sjdName(tuple.get(2, String.class))
                .candidateName(tuple.get(3, String.class))
                .phoneNumber(tuple.get(4, String.class))
                .email(tuple.get(5, String.class))
                .noticePeriod(tuple.get(7, Integer.class))
                .candidateStatus(commonUtil.getNameFromId(tuple.get(9, Integer.class), LookupType.CANDIDATE_STATUS))
                .eventCreatedOn(Date.from(tuple.get(10, Instant.class)))
                .recruiterName(tuple.get(11, String.class))
                .operations(commonUtil.getNameFromId(tuple.get(12,Integer.class),LookupType.OPERATION))
                .build();
        if (tuple.get(6) != null) {
            dto.setExperience(tuple.get(6, BigDecimal.class).floatValue());
        }

        if (tuple.get(8) != null) {
            dto.setQcRating(tuple.get(8, BigDecimal.class).floatValue());
        }
        return dto;
    }

    private CellStyle createBorderStyle(Workbook wb) {
        BorderStyle thin = BorderStyle.THIN;
        Short black = IndexedColors.BLACK.getIndex();
        CellStyle style = wb.createCellStyle();
        style.setBorderTop(thin);
        style.setTopBorderColor(black);
        style.setBorderRight(thin);
        style.setRightBorderColor(black);
        style.setBorderBottom(thin);
        style.setBottomBorderColor(black);
        style.setBorderLeft(thin);
        style.setLeftBorderColor(black);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private void populateHeaderRow(Workbook wb, Row row, Set<String> headers) {
        CellStyle headerStyle = createBorderStyle(wb);
        Font font = wb.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        int index = 0;
        for (String header : headers) {
            Cell cell = row.createCell(index++);
            cell.setCellStyle(headerStyle);
            cell.setCellValue(header);
        }
    }

    private void populateDataRow(CellStyle center, Row r, SourcerReportDto report) {
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);
        Cell c1 = r.createCell(0);
        c1.setCellValue(report.getSjdId());

        Cell c2 = r.createCell(1);
        c2.setCellValue(report.getSjdName());

        Cell c3 = r.createCell(2);
        c3.setCellValue(report.getCandidateName());

        Cell c4 = r.createCell(3);
        c4.setCellValue(report.getPhoneNumber());

        Cell c5 = r.createCell(4);
        c5.setCellValue(report.getEmail());

        Cell c6 = r.createCell(5);
        c6.setCellStyle(center);
        c6.setCellValue(nf.format(report.getExperience()));

        Cell c7 = r.createCell(6);
        c7.setCellStyle(center);
        c7.setCellValue(report.getNoticePeriod());

        Cell c8 = r.createCell(7);
        c8.setCellStyle(center);
        if (report.getQcRating() != null)
            c8.setCellValue(nf.format(report.getQcRating()));

        Cell c9 = r.createCell(8);
        c9.setCellValue(report.getCandidateStatus());

        Cell c10 = r.createCell(9);
        c10.setCellValue(report.getRecruiterName());

        DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");

        Cell c11 = r.createCell(10);
        c11.setCellValue(dateFormatter.format(report.getEventCreatedOn()));

        Cell c12 = r.createCell(11);
        c12.setCellValue(report.getOperations());
    }

}
