package com.exams.trees;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class TreeProblems {

	public static void main(String[] args) {

		Node rootNode = new Node(10);
		rootNode.leftNode = new Node(8);
		rootNode.rightNode = new Node(12);
		rootNode.leftNode.leftNode = new Node(6);
		rootNode.leftNode.rightNode = new Node(9);
		rootNode.rightNode.leftNode = new Node(11);
		rootNode.rightNode.rightNode = new Node(15);
		// Left, root, Right --- Ascending Order BST Inorder
		System.out.println("InorderTraversal: " + inOrderTraversalIterative(rootNode));
		inOrderTraversalrecurssive(rootNode);
		System.out.println();
		// Root, Left, right
		System.out.println("PreorderTraversal: " + preOrderTraversalIterative(rootNode));
		// Left, Right, Root
		System.out.println("PostorderTraversal:" + postorderIterative(rootNode));
		System.out.println(maxDepth(rootNode));
		System.out.println(search(rootNode , 11));
		printLeafNodes(rootNode);
	}
	
	public static void printLeafNodes(Node root) {
        if (root == null) return;
        
        if (root.leftNode == null && root.rightNode == null) {
            // Leaf node found, print its value
            System.out.print(root.data + " ");
        }
        // Recursively traverse left and right subtrees
        printLeafNodes(root.leftNode);
        printLeafNodes(root.rightNode);
    }
	
	
	public static List<Integer> inOrderTraversalIterative(Node rootnode) {
		List<Integer> list = new ArrayList<Integer>();
		if(rootnode == null) {
			return null;
		}
		Stack<Node> s = new Stack<>();
		Node curr = rootnode;
		while(curr!=null || !s.isEmpty()) {
			
			while(curr!=null) {
				s.push(curr);
				curr = curr.leftNode;
			}
			curr = s.pop();
			list.add(curr.data);
			curr = curr.rightNode;	
		}
		return list;	
	}
	
	public static void  inOrderTraversalrecurssive(Node rootnode) {
		if(rootnode == null) {
			return ;
		}
		inOrderTraversalrecurssive(rootnode.leftNode);
		System.out.print(rootnode.data + ", ");
		inOrderTraversalrecurssive(rootnode.rightNode);
	}
	
	public static List<Integer> preOrderTraversalIterative(Node rootnode) {
		List<Integer> list = new ArrayList<Integer>();
		if(rootnode == null) {
			return null;
		}
		Stack<Node> s = new Stack<>();
		s.push(rootnode);
		while(!s.isEmpty()) {
			Node curr = s.pop();
			list.add(curr.data);
			if(curr.rightNode != null) {
				s.add(curr.rightNode);
			}
			if(curr.leftNode != null) {
				s.add(curr.leftNode);
			}
		}
		return list;
		
	}
	
	public static List<Integer> postorderIterative(Node root) {
		List<Integer> list = new ArrayList<Integer>();
        if (root == null) return list;
        
        Stack<Node> stack1 = new Stack<>();
        Stack<Node> stack2 = new Stack<>();
        
        stack1.push(root);
        
        while (!stack1.isEmpty()) {
            Node curr = stack1.pop();
            stack2.push(curr);
            
            if (curr.leftNode != null) stack1.push(curr.leftNode);
            if (curr.rightNode != null) stack1.push(curr.rightNode);
        }
        while (!stack2.isEmpty()) {
        	list.add(stack2.pop().data);
        }
		return list;
    }
	
	
	

	public static int maxDepth(Node root) {
		if (root == null) {
			return 0;
		}
		int maxLeft = maxDepth(root.leftNode);
		int maxRight = maxDepth(root.rightNode);
		return Math.max(maxLeft, maxRight) + 1;
	}
	
	public static boolean search(Node root , int target) {
		Node current = root;
		while(current.data != target) {
			if(current != null) {
				System.out.println(current.data);
				if(current.data < target) {
					current = current.rightNode;
				}
				else {
					current = current.leftNode;	
                }
			}
			if(current == null) {
				return false;
			}
		}
		return true;
	}

}
