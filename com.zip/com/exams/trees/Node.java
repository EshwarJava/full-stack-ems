package com.exams.trees;

public class Node {
	int data;
	Node leftNode;
	Node rightNode;

	Node(int data) {
		this.data = data;
		this.leftNode = null;
		this.rightNode = null;
	}
}
