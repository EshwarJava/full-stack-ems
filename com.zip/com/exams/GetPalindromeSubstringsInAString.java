package com.exams;

import java.util.ArrayList;
import java.util.List;

public class GetPalindromeSubstringsInAString {

	public static void main(String[] args) {
		String str = "abcbbcbc";
		List<String> palindromeSubStrings = getPalindromeSubStrings(str);
		palindromeSubStrings.stream().forEach(System.out::println);
	}

	private static List<String> getPalindromeSubStrings(String str) {
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < str.length(); i++) {
			for (int j = i+1; j <= str.length(); j++) {
				String s = str.substring(i, j);
				boolean b = isPalindromeSubstring(s);
				if (b == true) {
					list.add(s);
				}
			}
		}
		return list;
	}

	private static boolean isPalindromeSubstring(String s) {
		int i = 0;
		int j = s.length() -1;
		while (i <= j) {
			char start = s.charAt(i);
			char end = s.charAt(j);
			if (start != end) {
				return false;
			} else {
				i++;
				j--;
			}
		}
		return true;
	}

}
