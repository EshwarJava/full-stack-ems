package com.peopletech.fractionable.constants;

public class AppConstants {
    public static final String USER_ID_HEADER = "userId";

    public enum SjdEventTypes {
        SJD_CREATED,
        SJD_DETAILS_UPDATED,
        CANDIDATE_ADDED,
        CANDIDATE_REMOVED,
        SJD_STATUS_CHANGED,
        QUESTIONNAIRE_ATTACHED;
    }

    private AppConstants() {
    }
}
