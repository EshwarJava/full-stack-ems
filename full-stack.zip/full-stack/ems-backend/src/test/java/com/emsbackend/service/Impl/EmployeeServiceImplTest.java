package com.emsbackend.service.Impl;

import com.emsbackend.dto.EmployeeDTO;
import com.emsbackend.exception.ResourceNotFoundException;
import com.emsbackend.mapper.EmployeeMapper;
import com.emsbackend.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;


import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@RunWith(MockitoJUnitRunner.class)
class EmployeeServiceImplTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getEmployeeById() {
        Long empId = 1L;
        EmployeeDTO expectedEmployeeDTO = new EmployeeDTO(1L, "Eshwar", "Chillamcherla", "eshwarsaichillamcherla@gmail.com");
        Mockito.when(employeeRepository.findById(empId)).thenReturn(Optional.of(EmployeeMapper.mapToEmployee(expectedEmployeeDTO)));
        EmployeeDTO actualEmployeeDTO = employeeService.getEmployeeById(empId);
        assertEquals(expectedEmployeeDTO, actualEmployeeDTO);
    }

    @Test
    public void testGetEmployeeById_NotFound() {
        Long empId = 1L;
        Mockito.when(employeeRepository.findById(empId)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> employeeService.getEmployeeById(empId));
    }

}