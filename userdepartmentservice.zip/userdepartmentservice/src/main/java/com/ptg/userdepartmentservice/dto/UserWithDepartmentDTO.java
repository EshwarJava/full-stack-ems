package com.ptg.userdepartmentservice.dto;

import lombok.*;
import org.springframework.web.bind.annotation.GetMapping;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserWithDepartmentDTO {
    String name;
    String dob;
    int age;
    int deptId;
}
