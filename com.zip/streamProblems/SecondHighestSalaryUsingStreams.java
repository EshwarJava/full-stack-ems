package streamProblems;

import java.util.HashMap;
import java.util.Map;

public class SecondHighestSalaryUsingStreams {

	public static void main(String[] args) {
		Map<String, Integer> salaryMap = new HashMap<>();
		salaryMap.put("Alice", 3000);
		salaryMap.put("Bob", 2500);
		salaryMap.put("Charlie", 4000);
		salaryMap.put("David", 2000);
		salaryMap.put("Eve", 3500);

		// Find the second highest salary person and their salary
		Map.Entry<String, Integer> secondHighestEntry = salaryMap.entrySet().stream()
				.sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue())) // Sort by salary in
																							// descending order
				.skip(1) // Skip the first entry, which is the highest salary
				.findFirst().orElse(null);

		if (secondHighestEntry != null) {
			System.out.println("Second highest salary person: " + secondHighestEntry.getKey());
			System.out.println("Salary: " + secondHighestEntry.getValue());
		} else {
			System.out.println("No second highest salary found.");
		}

	}

}
