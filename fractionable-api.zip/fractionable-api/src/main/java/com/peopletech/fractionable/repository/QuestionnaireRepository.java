package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.QuestionnaireBO;
import com.peopletech.fractionable.entity.QuestionnaireTypeBO;
import com.peopletech.fractionable.entity.SkillBO;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface QuestionnaireRepository extends CrudRepository<QuestionnaireBO, Integer> {
    List<QuestionnaireBO> findAllByQuestionnaireType(QuestionnaireTypeBO questionnaireType);

    List<QuestionnaireBO> findByQuestionnaireTypeAndSkillsIn(QuestionnaireTypeBO questionnaireType, List<SkillBO> skills);
}
