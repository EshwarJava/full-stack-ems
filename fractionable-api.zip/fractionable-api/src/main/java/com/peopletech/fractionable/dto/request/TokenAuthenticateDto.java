package com.peopletech.fractionable.dto.request;

import lombok.Data;

@Data
public class TokenAuthenticateDto {
    private String idToken;
}
