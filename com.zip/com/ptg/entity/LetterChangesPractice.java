package com.ptg.entity;

public class LetterChangesPractice {

	public static void main(String[] args) {
		System.out.println(LetterChanges("vudfkvbekvk"));
	}

	private static String LetterChanges(String str) {
		String ALPHABETS = "abcdefghijklmnopqrstuvwxyz";
		String ALPHABETS_CAPS = ALPHABETS.toUpperCase();
		String vowels = "aeiou";

		StringBuilder newStr = new StringBuilder();
		for (char c : str.toCharArray()) {
			int index = ALPHABETS.indexOf(c);
			char newChar;
			if (index > -1 && index < 25) {
				newChar = ALPHABETS.charAt(index + 1);
			} else {
				newChar = 'a';
			}
			if (vowels.indexOf(newChar) > -1) {
				newChar = Character.toUpperCase(newChar);
			}
			newStr.append(newChar);
			
			
		}
		return newStr.toString();
	}

}
