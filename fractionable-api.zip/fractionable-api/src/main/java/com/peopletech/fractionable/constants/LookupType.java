package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum LookupType {
    QUALIFICATION("qualification"),
    PRIORITY("priority"),
    PAY_TYPE("payType"),
    JOB_TYPE("jobType"),
    DOMAIN("domain"),
    COMPANY("company"),
    DEPARTMENT("department"),
    OPERATION("operation"),
    ROLE("role"),
    SOURCE_CHANNEL("sourceChannel"),
    CANDIDATE_STATUS("candidateStatus"),
    SJD_STATUS("sjdStatus"),
    CANDIDATE_EVENT_TYPE("candidateEventType"),
    SJD_EVENT_TYPE("sjdEventType"),
    CLIENT("client"),
    ANSWER_TYPE("answerType"),
    QUESTIONNAIRE_TYPE("questionnaireType");

    private final String type;

    LookupType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public static LookupType get(String type) {
        return Arrays.stream(LookupType.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Lookup type is invalid"));
    }

    public static Boolean isLookup(String type) {
        return Arrays.stream(LookupType.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .count() > 0;
    }

}
