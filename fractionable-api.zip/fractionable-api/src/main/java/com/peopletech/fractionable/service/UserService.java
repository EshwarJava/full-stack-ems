package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.dto.request.LoginRequestDto;
import com.peopletech.fractionable.entity.UserDetailsBO;

import java.util.List;

public interface UserService {
    public UserDetailsBO findByUserId(Integer id);

    public UserDetailsBO validateUserCredentials(LoginRequestDto loginRequest);

    public UserDetailsBO authenticateToken(String accessToken);

    public UserDetailsDto createUser(UserDetailsDto userDetails, Integer userId);

    UserDetailsDto updateUser(UserDetailsDto userDetails, Integer userId);

    public List<UserDetailsDto> getAllUsers();

    public List<UserDetailsDto> getUsersByRole(Integer roleId);

    public void changePassword(Integer userId, String password);
}
