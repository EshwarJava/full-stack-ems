package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.entity.SjdCandidateInfoBO;
import com.peopletech.fractionable.repository.SjdCandidateInfoRepository;
import com.peopletech.fractionable.service.SjdCandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SjdCandidateServiceImpl implements SjdCandidateService {

    @Autowired
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Override
    public SjdCandidateInfoBO addInfo(SjdCandidateInfoBO info) {
        return sjdCandidateInfoRepository.save(info);
    }
}
