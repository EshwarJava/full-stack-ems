package com.peopletech.fractionable.dto;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class AuditReportDto {
    private Integer sjdId;
    private String sjdName;
    private Integer candidateId;
    private String candidateName;
    private String recruiterName;
    private Boolean auditResult;
    private String auditComments;
    private String auditedBy;
    private Date auditedOn;
    private String operations;
}
