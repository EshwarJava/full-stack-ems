package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.SjdCandidateInfoDto;
import com.peopletech.fractionable.dto.SjdDto;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;
import com.peopletech.fractionable.service.SjdService;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sjd")
public class SjdController {

    @Autowired
    SjdService service;

    @Autowired
    DozerBeanMapper mapper;

    @GetMapping
    public List<SjdDto> getAllSjd(@RequestParam(required = false) Integer userId) {
        return service.getAllSjd(userId);
    }

    @GetMapping("/{id}")
    public SjdDto getSjd(@PathVariable Integer id) {
        return service.getSjd(id);
    }

    @PostMapping()
    public SjdDto addSjd(@RequestBody SjdDto sjdDto, @RequestHeader Integer userId) {
        return service.addSjd(sjdDto, userId);
    }

    @PatchMapping()
    public SjdDto updateSjd(@RequestBody SjdDto sjdDto, @RequestHeader Integer userId) {
        return service.updateSjd(sjdDto, userId);
    }

    @PostMapping("/candidate")
    public AppResponseDto<Integer> tagCandidateToSjd(@RequestBody TagCandidateRequest request, @RequestHeader Integer userId) {
        service.tagCandidateToSjd(request, userId);
        return new AppResponseDto<>(null, "Candidate tagged to SJD successfully");
    }

    @DeleteMapping("/candidate")
    public AppResponseDto<Integer> unTagCandidateFromSjd(@RequestBody SjdCandidateInfoDto request, @RequestHeader Integer userId) {
        service.unTagCandidateFromSjd(request, userId);
        return new AppResponseDto<>(null, "Candidate untagged from SJD successfully");
    }
}
