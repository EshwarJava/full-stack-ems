package com.peopletech.fractionable.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ResumeSearchResponseDto {
    private String resumeId;
    private Integer candidateId;
    private List<SjdDto> sjds;
}
