package com.exams;

import java.util.Stack;

public class isValidParenthesesStack {

	public static void main(String[] args) {
		String str = "({)}";
		System.out.println(isValid(str));

	}

	private static boolean isValid(String str) {
		char[] arr = str.toCharArray();
		Stack<Character> stack = new Stack<Character>();
		for (char ch : arr) {

			if (ch == '(' || ch == '{' || ch == '[') {
				stack.push(ch);
			} else if (ch == ')') {
				if (stack.isEmpty() || stack.peek() != '(') {
					return false;
				}
				stack.pop();
			} else if (ch == '}') {
				if (stack.isEmpty() || stack.peek() != '{') {
					return false;
				}
				stack.pop();
			} else if (ch == ']') {
				if (stack.isEmpty() || stack.peek() != '[') {
					return false;
				}
				stack.pop();
			}
		}
		return stack.isEmpty();
	}

}
