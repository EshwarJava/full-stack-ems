package com.ptg.entity;

import java.util.Arrays;

public class Problem2 {

	public static void main(String[] args) {

		int[] originalArray = { 2, 4, 10, 6, 8 };
		Arrays.sort(originalArray);
		int maxNumber = originalArray[originalArray.length - 1];

		int[] remainingArray = new int[originalArray.length - 1];
		for (int i = 0; i < originalArray.length - 1; i++) {
			remainingArray[i] = originalArray[i];
		}
		for (int i : remainingArray) {
			System.out.println(i);
		}
		
		if (maxNumber == -1) {
			System.out.println(checkSums(remainingArray, maxNumber));
		} else {
			// Find all possible sums in the modified array and check if any sum equals
			// maxNum
			if (checkSums(remainingArray, maxNumber)) {
				System.out.println(checkSums(remainingArray, maxNumber));
			} else {
				System.out.println(checkSums(remainingArray, maxNumber));
			}
		}
	}

	public static boolean checkSums(int[] arr, int targetSum) {
		return isSubsetSum(arr, arr.length, targetSum);
	}

	private static boolean isSubsetSum(int[] arr, int n, int targetSum) {
		if (targetSum == 0) {
			return true;
		}
		if (n == 0) {
			return false;
		}

		if (arr[n - 1] > targetSum) {
			return isSubsetSum(arr, n - 1, targetSum);
		}

		return isSubsetSum(arr, n - 1, targetSum) || isSubsetSum(arr, n - 1, targetSum - arr[n - 1]);
	}
}
