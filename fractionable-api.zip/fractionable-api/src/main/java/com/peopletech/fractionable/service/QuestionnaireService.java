package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.dto.QuestionDto;
import com.peopletech.fractionable.dto.QuestionnaireAnswerDto;
import com.peopletech.fractionable.dto.QuestionnaireDto;
import com.peopletech.fractionable.dto.request.SjdQuestionnaireRequestDto;

import java.util.List;

public interface QuestionnaireService {
    List<QuestionnaireDto> getAllQuestionnaire();

    List<QuestionnaireDto> getAllQuestionnaireByType(Integer questionnaireTypeId, List<LookupDto> skills);

    QuestionnaireDto getQuestionnaireById(Integer id);

    Integer saveQuestionnaire(QuestionnaireDto questionnaire, Integer userId);

    Integer updateQuestionnaire(QuestionnaireDto questionnaire, Integer userId);

    Integer saveQuestion(QuestionDto question);

    void deleteQuestion(Integer id);

    void tagQuestionnaireToSjd(SjdQuestionnaireRequestDto request, Integer userId);

    List<QuestionnaireAnswerDto> getQuestionnaireAnswers(Integer sjdId, Integer candidateId);

    void saveQuestionnaireAnswers(List<QuestionnaireAnswerDto> answers, Integer userId);

}
