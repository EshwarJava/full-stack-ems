package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "candidate_documents")
public class CandidateDocumentBO {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_documents_id_generator")
    @SequenceGenerator(name = "candidate_documents_id_generator", sequenceName = "candidate_documents_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "candidate_id")
    private Integer candidateId;

    @Column(name = "document_name")
    private String documentName;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "document_url")
    private String documentUrl;

    @OneToOne
    @JoinColumn(name = "created_by_id", referencedColumnName = "id")
    private UserDetailsBO createdBy;

    @Column(name = "created_on")
    private Date createdOn;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CandidateDocumentBO that = (CandidateDocumentBO) o;
        if (id != null || that.id != null)
            return Objects.equals(id, that.id);
        else
            return Objects.equals(candidateId, that.candidateId) && Objects.equals(documentUrl, that.documentUrl);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, candidateId, documentUrl);
    }
}
