package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public class QuestionDto {
    private Integer id;
    private String question;
    private Boolean required;
    private Integer answerTypeId;
}