package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.ClientBO;
import org.springframework.data.repository.CrudRepository;

public interface ClientRepository extends CrudRepository<ClientBO, Integer> {
}
