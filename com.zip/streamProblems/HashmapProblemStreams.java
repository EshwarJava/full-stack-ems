package streamProblems;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class HashmapProblemStreams {

	public static void main(String[] args) {

		Map<String, Integer> ageMap = new HashMap<>();
		ageMap.put("Alice", 30);
		ageMap.put("Bob", 25);
		ageMap.put("Charlie", 40);
		ageMap.put("David", 20);
		ageMap.put("Eve", 35);

		// Use streams to filter entries where age is greater than 25
		Map<String, Integer> filteredMap = ageMap.entrySet().stream().filter(entry -> entry.getValue() > 25)
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

		// Print the filtered entries
		filteredMap.forEach((name, age) -> System.out.println(name + ": " + age));

	}

}
