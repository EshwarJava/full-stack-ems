import React from 'react'

const FooterComponent = () => {
  return (
    <div>
      <footer className='footer'>
        <span>All rights reseved for eshwar</span>
      </footer>
    </div>
  )
}
export default FooterComponent
