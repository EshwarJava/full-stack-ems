package com.exams;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContainsNearByDuplicateHashMap {

	public static void main(String[] args) {

		int[] arr = new int[] { 1, 2, 3, 1, 2, 3 };
		int k = 2;
		System.out.println(containsNearbyDuplicate(arr, k));
		
	}

	// 1 -> 0
	// 0 -> 1
	// 1 -> 2
	// 1 -> 3

	public static boolean containsNearbyDuplicate(int[] arr, int k) {
		if (arr == null || arr.length <= 1) {
			return false;
		}
		Map<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < arr.length; i++) {
			int num = arr[i];
			if (map.containsKey(num)) {
				int y = map.get(num);
				if (Math.abs(y - i) <= k) {
					return true;
				}
				map.put(num, i);
			} else {
				map.put(num, i);
			}
		}
		return false;
	}

}
