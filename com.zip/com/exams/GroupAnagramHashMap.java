package com.exams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupAnagramHashMap {

	public static void main(String[] args) {

		String[] arr = new String[] { "eat", "tea", "tan", "ate", "nat", "bat" };
		List<List<String>> res = groupAnagrams(arr);
		System.out.println(res);
	}

	public static List<List<String>> groupAnagrams(String[] strs) {
		List<List<String>> res = new ArrayList<>();
		Map<String, List<String>> map = new HashMap<>();
		for (String str : strs) {
			String sorted = sortedString(str);
			List<String> temp = new ArrayList<String>();
			if (map.containsKey(sorted)) {
				List<String> tempList = map.get(sorted);
				tempList.add(str);
				map.put(sorted, tempList);
			} else {
				temp.add(str);
				map.put(sorted, temp);
			}
		}
		for (List<String> list : map.values()) {
			res.add(list);
		}
		return res;
	}

	private static String sortedString(String str) {
		char[] charArr = str.toCharArray();
		Arrays.sort(charArr);
		return new String(charArr);
	}

}
