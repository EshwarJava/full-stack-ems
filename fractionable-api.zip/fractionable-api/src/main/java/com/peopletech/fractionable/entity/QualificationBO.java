package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "qualification_lookup")
public class QualificationBO {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "qualification_lookup_id_generator")
    @SequenceGenerator(name = "qualification_lookup_id_generator", sequenceName = "qualification_lookup_id_seq", allocationSize = 1)
    private Integer id;

    private String name;
}
