package streamProblems;

import java.util.Arrays;
import java.util.List;

public class SumOfEvenSumOfOddInList {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(5, 5, 6, 3, 3, 6, 4, 8);
		//mapToInt(Integer::intValue): This is another intermediate operation.
		//It transforms the elements of the stream into their integer representations. In other words,
		//it converts the stream of boxed integers (Integer) to a specialized stream of primitive integers (IntStream).
        //Integer::intValue is a method reference that's equivalent to the lambda expression (i) -> i.intValue().
		//It's extracting the integer value from each Integer object.
		int sumOfEven = list.stream().filter(i -> i % 2 == 0).mapToInt(Integer::intValue).sum();
		System.out.println(sumOfEven);
		int sumOfOdd = list.stream().filter(i -> i % 2 != 0).mapToInt(Integer::intValue).sum();
		System.out.println(sumOfOdd);
	}

}
