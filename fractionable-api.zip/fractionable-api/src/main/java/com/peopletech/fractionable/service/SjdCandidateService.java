package com.peopletech.fractionable.service;

import com.peopletech.fractionable.entity.SjdCandidateInfoBO;

public interface SjdCandidateService {
    public SjdCandidateInfoBO addInfo(SjdCandidateInfoBO info);
}
