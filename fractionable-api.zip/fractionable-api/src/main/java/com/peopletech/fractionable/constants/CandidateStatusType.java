package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum CandidateStatusType {

    NEW("New"),
    QC_RATED("QC Rated"),
    PROFILER_RATED("Profiler Rated"),
    ONLINE_TEST_SCHEDULED("Online Test Scheduled"),
    ONLINE_TEST_CLEARED("Online Test cleared"),
    TECH_INTERVIEW_1_SCHEDULED("Tech Interview-1 Scheduled"),
    TECH_INTERVIEW_1_CLEARED("Tech Interview-1 cleared"),
    TECH_INTERVIEW_2_SCHEDULED("Tech Interview-2 Scheduled"),
    TECH_INTERVIEW_2_CLEARED("Tech Interview-2 cleared"),
    TECH_INTERVIEW_3_SCHEDULED("Tech Interview-3 Scheduled"),
    TECH_INTERVIEW_3_CLEARED("Tech Interview-3 cleared"),
    TECH_INTERVIEW_4_SCHEDULED("Tech Interview-4 Scheduled"),
    TECH_INTERVIEW_4_CLEARED("Tech Interview-4 cleared"),
    TECH_INTERVIEW_5_SCHEDULED("Tech Interview-5 Scheduled"),
    TECH_INTERVIEW_5_CLEARED("Tech Interview-5 cleared"),
    CLIENT_INTERVIEW_SCHEDULED("Client Interview Scheduled"),
    CLIENT_INTERVIEW_CLEARED("Client Interview Cleared"),
    HR_INTERVIEW_SCHEDULED("HR Interview Scheduled"),
    HR_INTERVIEW_CLEARED("HR Interview Cleared"),
    DOCUMENT_VERIFICATION_STARTED("Document Verification Started"),
    DOCUMENT_VERIFICATION_COMPLETE("Document Verification Completed"),
    OFFER_APPROVED("Offer approved"),
    OFFER_RELEASED("Offer Released"),
    OFFER_ACCEPTED("Offer accepted"),
    CANDIDATE_JOINED("Joined"),
    CANDIDATE_REJECTED("Rejected"),
    CANDIDATE_NOT_INTERESTED("Not Interested"),
    CALLBACK("Callback"),
    ON_HOLD("On Hold");

    private final String type;

    CandidateStatusType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public static CandidateStatusType get(String type) {
        return Arrays.stream(CandidateStatusType.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Candidate status is invalid"));
    }

}
