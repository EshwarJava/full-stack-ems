package com.ptg.userdepartmentservice.repository;

import com.ptg.userdepartmentservice.entity.DepartmentBO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<DepartmentBO, Integer> {


}
