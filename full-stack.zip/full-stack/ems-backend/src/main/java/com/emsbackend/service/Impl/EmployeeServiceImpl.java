package com.emsbackend.service.Impl;

import com.emsbackend.dto.EmployeeDTO;
import com.emsbackend.entity.Employee;
import com.emsbackend.exception.ResourceNotFoundException;
import com.emsbackend.mapper.EmployeeMapper;
import com.emsbackend.repository.EmployeeRepository;
import com.emsbackend.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public EmployeeDTO addEmployee(EmployeeDTO employeeDto) {
        Employee employee = employeeRepository.save(EmployeeMapper.mapToEmployee(employeeDto));
        return EmployeeMapper.mapToEmployeeDTO(employee);
    }

    @Override
    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        List<EmployeeDTO> employeeDTos = employees.stream().map(employee -> EmployeeMapper.mapToEmployeeDTO(employee)).collect(Collectors.toList());
        return employeeDTos;
    }

    @Override
    public EmployeeDTO getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found for id" + id));
        return EmployeeMapper.mapToEmployeeDTO(employee);
    }

    @Override
    public void deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found for id" + id));
        employeeRepository.deleteById(id);
    }

    @Override
    public EmployeeDTO updateEmployee(Long id, EmployeeDTO employeeDTO) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found for id" + id));
        Employee updatedEmployee = new Employee();
        updatedEmployee.setEmployeeId(employee.getEmployeeId());
        updatedEmployee.setFirstName(employeeDTO.getFirstName());
        updatedEmployee.setEmail(employeeDTO.getEmail());
        updatedEmployee.setLastName(employeeDTO.getLastName());
        return EmployeeMapper.mapToEmployeeDTO(employeeRepository.save(updatedEmployee));
    }

}
