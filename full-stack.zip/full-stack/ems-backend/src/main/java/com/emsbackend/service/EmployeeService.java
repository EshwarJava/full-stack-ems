package com.emsbackend.service;

import com.emsbackend.dto.EmployeeDTO;

import java.util.List;

public interface EmployeeService {
    EmployeeDTO addEmployee(EmployeeDTO employeeDto);

    List<EmployeeDTO> getAllEmployees();

    EmployeeDTO getEmployeeById(Long id);

    void deleteEmployee(Long id);

    EmployeeDTO updateEmployee(Long id, EmployeeDTO employeeDTO);

}
