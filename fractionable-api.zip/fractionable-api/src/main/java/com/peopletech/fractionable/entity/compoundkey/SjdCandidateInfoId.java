package com.peopletech.fractionable.entity.compoundkey;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SjdCandidateInfoId implements Serializable {

    @Column(name = "sjd_id")
    Integer sjdId;

    @Column(name = "candidate_id")
    Integer candidateId;
}
