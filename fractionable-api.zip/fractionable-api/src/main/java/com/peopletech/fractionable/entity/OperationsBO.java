package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "user_operations_lookup")
public class OperationsBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_operations_lookup_id_generator")
    @SequenceGenerator(name = "user_operations_lookup_id_generator", sequenceName = "user_operations_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
