package com.exams;

import java.util.HashSet;
import java.util.Set;

public class LengthOfNonRepeatingLongestSubstring {

	public static int lengthOfLongestSubstringInString(String str) {
		if (str.length() == 0) {
			return 0;
		}
		int longest = 0;
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j <= str.length(); j++) {
				String s = str.substring(i, j);
				boolean b = hasNoRepeatingCharacters(s);
				if (b == true) {
					if (s.length() > longest) {
						longest = s.length();
					}
				}

			}
		}
		return longest;
	}

	public static int lengthOfLongestSubstring(String s) {
		if (s == null || s.length() == 0) {
			return 0;
		}
		int len = 0, lastDup = 0;
		HashSet<Character> set = new HashSet<Character>();

		for (int i = 0; i < s.length(); i++) {
			if (set.contains(s.charAt(i))) {
				while (set.contains(s.charAt(i))) {
					set.remove(s.charAt(lastDup));
					lastDup++;
				}
			}
			set.add(s.charAt(i));
			len = Math.max(len, set.size());
		}

		return len;
	}

	private static boolean hasNoRepeatingCharacters(String s) {
		int len = s.length();
		char[] arr = s.toCharArray();
		Set<Character> set = new HashSet<>();
		for (Character character : arr) {
			set.add(character);
		}
		int res = set.toArray().length;
		if (res == len) {
			return true;
		} else {
			return false;
		}

	}

	public static void main(String[] args) {
		String str = "pwwkew";
		int length = lengthOfLongestSubstring(str);
		System.out.println(length);

	}

}
