package com.peopletech.fractionable.util;

import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.shaded.json.JSONObject;
import com.nimbusds.jose.shaded.json.parser.JSONParser;
import lombok.extern.slf4j.Slf4j;

import java.net.URL;
import java.util.Base64;
import java.util.List;

@Slf4j
public class MicrosoftTokenVerifierUtil {

    private final List<JWK> publicKeyList;

    public MicrosoftTokenVerifierUtil(String url) throws Exception {
        JWKSet jwkSet = JWKSet.load(new URL(url));
        publicKeyList = jwkSet.getKeys();
    }

    public String verifyToken(String token) {
        try {
            JWSObject jwsObject = JWSObject.parse(token);
            String kid = jwsObject.getHeader().getKeyID();

            JWK jwk = publicKeyList.stream().filter(key -> key.getKeyID().equalsIgnoreCase(kid)).findFirst().orElseThrow();
            Boolean isValid = jwsObject.verify(new RSASSAVerifier(jwk.toRSAKey().toRSAPublicKey()));
            if (isValid) {
                String payLoadString = new String(Base64.getDecoder().decode(jwsObject.getPayload().toBase64URL().toString()));

                JSONObject jsonObject = (JSONObject) new JSONParser().parse(payLoadString);
                return (String) jsonObject.get("preferred_username");

            }
        } catch (Exception e) {
            log.info("Exception occurred during token verification", e.getStackTrace());
        }

        return null;
    }
}
