package com.ptg.entity;

import java.util.ArrayList;
import java.util.List;

public class Problem3 {

	public static void main(String[] args) {

		int[] arr = { 2, 4, 6, 8 };

		List<Integer> results = collectAllSums(arr);
		System.out.print(results);
		System.out.println("All possible sums:");
		for (int sum : results) {
			System.out.println(sum);
		}
	}

	public static List<Integer> collectAllSums(int[] arr) {
		List<Integer> results = new ArrayList<>();
		generateSums(arr, 0, 0, results, new boolean[arr.length]);
		return results;
	}

	private static void generateSums(int[] arr, int index, int currentSum, List<Integer> results, boolean[] used) {
		if (index == arr.length) {
			results.add(currentSum);
			return;
		}

		// Include the current element in the sum if it's not already used
		if (!used[index]) {
			used[index] = true;
			generateSums(arr, index + 1, currentSum + arr[index], results, used);
			used[index] = false; // Backtrack to explore other possibilities
		}

		// Exclude the current element from the sum
		generateSums(arr, index + 1, currentSum, results, used);
	}

}
