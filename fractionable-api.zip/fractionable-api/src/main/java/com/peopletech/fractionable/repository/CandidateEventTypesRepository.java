package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateEventTypeBO;
import org.springframework.data.repository.CrudRepository;

public interface CandidateEventTypesRepository extends CrudRepository<CandidateEventTypeBO, Integer> {
}
