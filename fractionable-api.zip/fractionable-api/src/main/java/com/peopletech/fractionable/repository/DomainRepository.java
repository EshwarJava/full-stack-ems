package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.DomainBO;
import org.springframework.data.repository.CrudRepository;

public interface DomainRepository extends CrudRepository<DomainBO, Integer> {
}
