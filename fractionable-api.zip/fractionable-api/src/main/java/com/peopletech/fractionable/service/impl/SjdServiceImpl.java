package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.*;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.entity.compoundkey.SjdCandidateInfoId;
import com.peopletech.fractionable.entity.compoundkey.SjdSkillMappingId;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.service.SjdEventService;
import com.peopletech.fractionable.service.SjdService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import jakarta.transaction.Transactional;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SjdServiceImpl implements SjdService {

    @Autowired
    SjdRepository sjdRepository;

    @Autowired
    SjdSkillMappingRepository sjdSkillMappingRepository;

    @Autowired
    SjdUserRepository sjdUserRepository;

    @Autowired
    CandidateRepository candidateRepository;

    @Autowired
    SjdEventService sjdEventService;

    @Autowired
    private DozerBeanMapper mapper;

    @Autowired
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Autowired
    private CandidateEventService candidateEventService;


    @Autowired
    private CommonUtil commonUtil;

    @Autowired
    private LookupService lookupService;


    @Override
    public SjdDto getSjd(int id) {
        SjdBO bo = sjdRepository.findById(id).orElseThrow(() -> new NoSuchElementException("SJD not found: id=" + id));
        SjdDto sjdDto = mapper.map(bo, SjdDto.class);
        List<SjdSkillMappingBO> skills = sjdSkillMappingRepository.findAllBySjdId(id);
        sjdDto.setSkills(
                skills.stream().map(s -> {
                    SjdSkillMappingDto skillMapping = new SjdSkillMappingDto();
                    skillMapping.setSkill(mapper.map(s.getSkill(), LookupDto.class));
                    skillMapping.setMinExperience(s.getMinExperience());
                    return skillMapping;
                }).toList()
        );
        sjdDto.setEvents(commonUtil.mapList(sjdEventService.getEventsForSjd(id), SjdEventDto.class));
        return sjdDto;
    }

    @Override
    @Transactional
    public SjdDto addSjd(SjdDto sjdDto, Integer userId) {
        sjdDto.setCreatedBy(UserDetailsDto.builder().id(userId).build());
        sjdDto.setCreatedOn(new Date());
        sjdDto.setModifiedOn(new Date());
        sjdDto.setModifiedById(userId);
        sjdDto.setSjdStatusId(commonUtil.getSjdStatus(SjdStatusType.NEW.getType()).getId());
        sjdDto.setActive(true);
        List<SjdSkillMappingDto> skills = sjdDto.getSkills();
        sjdDto.setSkills(null);
        SjdBO sjdBO = sjdRepository.save(mapper.map(sjdDto, SjdBO.class));
        List<SjdSkillMappingBO> sjdSkillMappingBOList = skills.stream().map(s -> {
            SjdSkillMappingBO sjdSkillMappingBO = new SjdSkillMappingBO(sjdBO.getId(), s.getSkill().getId());
            sjdSkillMappingBO.setSjd(SjdBO.builder().id(sjdBO.getId()).build());
            sjdSkillMappingBO.setSkill(new SkillBO(s.getSkill().getId(), null));
            sjdSkillMappingBO.setMinExperience(s.getMinExperience());
            return sjdSkillMappingBO;
        }).toList();
        sjdSkillMappingRepository.saveAll(sjdSkillMappingBOList);
        sjdEventService.addEvent(sjdBO.getId(), userId, AppConstants.SjdEventTypes.SJD_CREATED.name(), String.valueOf(sjdBO.getId()));
        return mapper.map(sjdBO, SjdDto.class);
    }

    @Override
    @Transactional
    public SjdDto updateSjd(SjdDto sjdDto, Integer userId) {
        // TODO: Temporaty fix since we are getting error in SJD update
        sjdDto.setQuestionnaire(null);

        sjdDto.setModifiedById(userId);
        sjdDto.setModifiedOn(new Date());
        SjdBO sjd = sjdRepository.findById(sjdDto.getId()).orElseThrow(() ->
                new NoSuchElementException("SJD not found, id:" + sjdDto.getId()));
        boolean isStatusUpdate = (sjdDto.getSjdStatusId() != null) && (sjdDto.getSjdStatusId() != sjd.getSjdStatus().getId());
        mapper.map(sjdDto, sjd);

        SjdBO updatedSjd = sjdRepository.save(sjd);

        List<SjdSkillMappingBO> boSkills = sjdSkillMappingRepository.findAllBySjdId(sjd.getId());
        List<SjdSkillMappingDto> dtoSkills = sjdDto.getSkills();
        if (dtoSkills != null) {
            List<Integer> existingSkillIds = boSkills.stream().map(s -> s.getSkill().getId()).toList();
            List<Integer> newSkillIds = dtoSkills.stream().map(s -> s.getSkill().getId()).toList();

            List<SjdSkillMappingId> toBeDeleted = existingSkillIds.stream()
                    .filter(element -> !newSkillIds.contains(element))
                    .map(skillId -> new SjdSkillMappingId(sjd.getId(), skillId))
                    .toList();
            if (!toBeDeleted.isEmpty())
                sjdSkillMappingRepository.deleteAllById(toBeDeleted);

            List<SjdSkillMappingBO> toBeAdded = dtoSkills.stream()
                    .map(s -> {
                        SjdSkillMappingBO sjdSkillMappingBO = new SjdSkillMappingBO(sjd.getId(), s.getSkill().getId());
                        sjdSkillMappingBO.setSjd(SjdBO.builder().id(sjd.getId()).build());
                        sjdSkillMappingBO.setSkill(new SkillBO(s.getSkill().getId(), null));
                        sjdSkillMappingBO.setMinExperience(s.getMinExperience());
                        return sjdSkillMappingBO;
                    })
                    .toList();
            sjdSkillMappingRepository.saveAll(toBeAdded);
        }

        sjdEventService.addEvent(updatedSjd.getId(), userId,
                isStatusUpdate
                        ? AppConstants.SjdEventTypes.SJD_STATUS_CHANGED.name()
                        : AppConstants.SjdEventTypes.SJD_DETAILS_UPDATED.name(),
                isStatusUpdate ? commonUtil.getNameFromId(sjdDto.getSjdStatusId(), LookupType.SJD_STATUS) :
                        String.valueOf(sjdDto.getId()));

        return mapper.map(updatedSjd, SjdDto.class);
    }

    private List<SjdDto> addTotalCandidatesToSjd(List<SjdDto> sjdList) {

        List<Integer> sjdIdList = sjdList.stream().map((sjd) -> sjd.getId()).toList();
        List<Tuple> tuples = sjdCandidateInfoRepository.getCandidatesFromSjdList(sjdIdList);
        Map<Integer, Long> totalCandidateMap = tuples.stream().map((tuple) ->
                        new AbstractMap.SimpleEntry<Integer, Long>(tuple.get(0, Integer.class), tuple.get(1, Long.class)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        return sjdList.stream().map((sjd) -> {
            sjd.setTotalCandidates(totalCandidateMap.get(sjd.getId()) == null ? 0 : totalCandidateMap.get(sjd.getId()).intValue());
            return sjd;
        }).toList();
    }

    @Override
    public List<SjdDto> getAllSjd(Integer userId) {
        List<SjdDto> sjdDtoList = userId == null ? commonUtil.mapItreable(sjdRepository.findAll(), SjdDto.class)
                : sjdUserRepository.findAllByUserId(userId).stream()
                .map(sjdUser -> mapper.map(sjdUser.getSjd(), SjdDto.class)).toList();
        sjdDtoList = sjdDtoList.stream().filter((sjd) -> sjd.getActive()).toList();
        return addTotalCandidatesToSjd(sjdDtoList);
    }

    @Override
    public void tagCandidateToSjd(TagCandidateRequest request, Integer userId) {

        if (request.getCandidateId() == null) {
            CandidateBO candidate = candidateRepository
                    .findByResumeId(request.getResumeId())
                    .orElseThrow(() -> new NoSuchElementException(String.format("Resume id %s not found", request.getResumeId())));
            request.setCandidateId(candidate.getId());
        }
        SjdCandidateInfoBO info = new SjdCandidateInfoBO(request.getSjdId(), request.getCandidateId());
        info.setCandidate(CandidateBO.builder().id(request.getCandidateId()).build());
        info.setSjd(SjdBO.builder().id(request.getSjdId()).build());
        info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.NEW.name()));
        info.setCreatedBy(userId);
        info.setCreatedOn(new Date());
        sjdCandidateInfoRepository.save(info);

        List<SjdCandidateInfoBO> candidates = sjdCandidateInfoRepository.findBySjdId(request.getSjdId());
        if (candidates.size() == 1) {
            SjdDto sjd = new SjdDto();
            sjd.setId(request.getSjdId());
            sjd.setSjdStatusId(commonUtil.getSjdStatus(SjdStatusType.IN_PROGRESS.getType()).getId());
            updateSjd(sjd, userId);
        }

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_TAGGED_TO_SJD.name()).getId())
                        .description(String.valueOf(info.getSjd().getId()))
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
        sjdEventService.addEvent(info.getSjd().getId(), userId, AppConstants.SjdEventTypes.CANDIDATE_ADDED.name(), String.valueOf(info.getCandidate().getId()));
    }

    @Override
    public void unTagCandidateFromSjd(SjdCandidateInfoDto request, Integer userId) {
        sjdCandidateInfoRepository.deleteById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()));

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(request.getSjdId())
                        .candidateId(request.getCandidateId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_UNTAGGED_FROM_SJD.name()).getId())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
        sjdEventService.addEvent(
                request.getSjdId(),
                userId,
                AppConstants.SjdEventTypes.CANDIDATE_REMOVED.name(),
                String.valueOf(request.getCandidateId()));
    }
}
