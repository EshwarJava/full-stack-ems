package com.peopletech.fractionable.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidateInterviewDto {
    private Integer id;
    private Integer sjdId;
    private Integer candidateId;
    private UserDetailsDto evaluator;
    private String interviewLevel;
    private Date startTime;
    private Date endTime;
    private String feedback;
    private String recording;
    private Boolean isRecommended;
    private Integer createdBy;
    private Date createdOn;
    private Integer modifiedBy;
    private Date modifiedOn;
}
