package com.ptg.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class mapAndComparatorProblem {

	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<>();
		map.put(1, "Eshwar");
		map.put(2, "Sidu");
		map.put(3, "peopletech");
		map.put(4, "Drive");
		map.put(5, "goat");
		List<String> list = new ArrayList<>();
		map.forEach((key, value) -> list.add(value));
		Comparator<String> comparator = new Comparator<String>() {
			public int compare(String s1, String s2) {
				if (s1.length() > s2.length()) {
					return -1;
				} else if (s1.length() < s2.length()) {
					return 1;
				} else {
					return 0;
				}
			}
		};
		Collections.sort(list, comparator);
		System.out.println(list);
		
		

		List<Integer> integersList = new ArrayList<>();
		map.forEach((key, value) -> {
			if (value.length() == 4) {
				integersList.add(key);
			}

		});

		for (Map.Entry<Integer, String> entry : map.entrySet()) {
			if (entry.getValue().length() == 4) {
				integersList.add(entry.getKey());
			}
		}
		System.out.println(integersList);

	}

}
