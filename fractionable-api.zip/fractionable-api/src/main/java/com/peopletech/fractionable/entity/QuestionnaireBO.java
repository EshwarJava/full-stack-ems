package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Data
@Table(name = "questionnaire")
public class QuestionnaireBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionnaire_id_generator")
    @SequenceGenerator(name = "questionnaire_id_generator", sequenceName = "questionnaire_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;

    @OneToOne
    @JoinColumn(name = "questionnaire_type_id", referencedColumnName = "id")
    private QuestionnaireTypeBO questionnaireType;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "questionnaire_question_mapping",
            joinColumns = @JoinColumn(
                    name = "questionnaire_id", referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "question_id", referencedColumnName = "id"
            )
    )
    private List<QuestionBO> questions = new ArrayList<>();

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
    @JoinTable(
            name = "questionnaire_skills_mapping",
            joinColumns = @JoinColumn(
                    name = "questionnaire_id", referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "skill_id", referencedColumnName = "id"
            )
    )
    private List<SkillBO> skills = new ArrayList<>();

    @OneToOne
    @JoinColumn(name = "created_by_id", referencedColumnName = "id")
    private UserDetailsBO createdBy;

    @Column(name = "created_on")
    private Date createdOn;
}