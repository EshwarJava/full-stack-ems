package com.peopletech.fractionable.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.text.ParseException;
import java.util.NoSuchElementException;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(InvalidCredentialsException.class)
    @ResponseStatus(code = HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ApplicationError handleInvalidCredentialsException(InvalidCredentialsException ex, HandlerMethod handler) {
        return new ApplicationError(ex.getMessage());
    }


    @ExceptionHandler({IllegalArgumentException.class, ParseException.class})
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ApplicationError handleIllegalArgumentException(IllegalArgumentException ex, HandlerMethod handler) {
        return new ApplicationError(ex.getMessage());
    }

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(code = HttpStatus.NOT_FOUND)
    @ResponseBody
    public ApplicationError handleNoSuchElementException(NoSuchElementException ex, HandlerMethod handler) {
        return new ApplicationError(ex.getMessage());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ApplicationError handleDataIntegrityViolationException(DataIntegrityViolationException ex, HandlerMethod handler) {
        return new ApplicationError("Bad request.");
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ApplicationError handleException(Exception ex, HandlerMethod handler) {
        return new ApplicationError("Something went wrong..");
    }
}
