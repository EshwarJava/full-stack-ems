package com.ptg.userdepartmentservice.repository;

import com.ptg.userdepartmentservice.entity.DepartmentBO;
import com.ptg.userdepartmentservice.entity.UserBO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.transaction.Transactional;
import java.util.List;

@SpringBootTest
class UserRepositoryTest {

    @Autowired
    UserRepository userRepository;


    @Autowired
    DepartmentRepository departmentRepository;

    @Test
    public void saveUserWithDept() {

        int deptId = 2;
        DepartmentBO departmentBO = departmentRepository.findById(2).get();
        UserBO userBO = UserBO.builder().name("cruge").age(65).dob("gvseuveh").build();
        userBO.setDepartmentBO(departmentBO);

        userRepository.save(userBO);


    }


}

