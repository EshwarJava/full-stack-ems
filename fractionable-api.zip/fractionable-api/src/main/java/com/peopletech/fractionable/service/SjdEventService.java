package com.peopletech.fractionable.service;

import com.peopletech.fractionable.entity.SjdEventBO;

import java.util.List;

public interface SjdEventService {
    void addEvent(Integer sjdId, Integer userId, String eventType, String description);

    List<SjdEventBO> getEventsForSjd(Integer sjdId);
}
