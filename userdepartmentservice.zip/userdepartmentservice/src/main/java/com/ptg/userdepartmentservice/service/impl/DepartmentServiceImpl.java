package com.ptg.userdepartmentservice.service.impl;

import com.ptg.userdepartmentservice.dto.DepartmentUpdateDTO;
import com.ptg.userdepartmentservice.entity.DepartmentBO;
import com.ptg.userdepartmentservice.exception.DepartmentNotFoundException;
import com.ptg.userdepartmentservice.repository.DepartmentRepository;
import com.ptg.userdepartmentservice.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {
    @Autowired
    DepartmentRepository departmentRepository;

    @Override
    public DepartmentBO updateDepartmentofDeptId(DepartmentUpdateDTO departmentUpdateDTO, Integer deptId) {
        DepartmentBO department = departmentRepository.findById(deptId).orElseThrow(() -> new DepartmentNotFoundException("Dept not found"));
        department.setDeptName(departmentUpdateDTO.getName());
        return departmentRepository.save(department);
    }

    @Override
    public DepartmentBO insertDepartment(DepartmentBO departmentBO) {
        return departmentRepository.save(departmentBO);
    }

    @Override
    public DepartmentBO getDepartmentByDeptId(Integer id) {
        return departmentRepository.findById(id).orElseThrow(() -> new DepartmentNotFoundException("Department not found for ID: " + id));
    }

    @Override
    public List<DepartmentBO> getAllDepartments() {
        return departmentRepository.findAll();
    }


}
