package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.CandidateEventDto;

public interface CandidateEventService {
    Integer addEvent(CandidateEventDto candidateEvent, Integer userId);
}
