package com.ptg.userdepartmentservice.controller;

import com.ptg.userdepartmentservice.dto.UserWithDepartmentDTO;
import com.ptg.userdepartmentservice.entity.UserBO;
import com.ptg.userdepartmentservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("/{id}")
    public UserBO getUserWithDepartmentDetails(@PathVariable(name = "id") Integer userId) {
        return userService.getUserAndDepartmentDetails(userId);
    }

    @GetMapping("listOfUsers/{deptId}")
    List<UserBO> getListOfUsersWithDeptId(@PathVariable Integer deptId) {
        return userService.listOfUsersOfDepartment(deptId);
    }
    @PostMapping
    public UserBO insertUser(@RequestBody UserWithDepartmentDTO userWithDepartmentDTO) {
        return userService.addUser(userWithDepartmentDTO);
    }

    @DeleteMapping("/{userId}")
    public String deleteUser(@PathVariable Integer userId){
        return userService.deleteUser(userId);
    }


}
