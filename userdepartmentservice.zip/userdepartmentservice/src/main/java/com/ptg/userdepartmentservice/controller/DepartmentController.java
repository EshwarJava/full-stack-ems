package com.ptg.userdepartmentservice.controller;


import com.ptg.userdepartmentservice.dto.DepartmentUpdateDTO;
import com.ptg.userdepartmentservice.entity.DepartmentBO;
import com.ptg.userdepartmentservice.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @Autowired
    DepartmentService departmentService;


    @PutMapping("/{deptId}")
    public DepartmentBO updateDepartment(@RequestBody DepartmentUpdateDTO departmentUpdateDTO, @PathVariable Integer deptId) {
        return departmentService.updateDepartmentofDeptId(departmentUpdateDTO, deptId);
    }

    @PostMapping
    public DepartmentBO addDepartment(@RequestBody DepartmentBO departmentBO) {
        return departmentService.insertDepartment(departmentBO);
    }

    @GetMapping("/{deptId}")
    public DepartmentBO getDepartmentDetails(@PathVariable(name = "deptId") Integer id) {
        return departmentService.getDepartmentByDeptId(id);
    }

    @GetMapping
    public List<DepartmentBO> getAllDepartmentDetails() {
        return departmentService.getAllDepartments();
    }

}
