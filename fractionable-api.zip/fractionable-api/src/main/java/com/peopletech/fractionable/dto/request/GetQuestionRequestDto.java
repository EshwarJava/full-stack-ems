package com.peopletech.fractionable.dto.request;

import com.peopletech.fractionable.dto.LookupDto;
import lombok.Data;

import java.util.List;

@Data
public class GetQuestionRequestDto {
    private Integer questionnaireType;
    private List<LookupDto> skills;
}
