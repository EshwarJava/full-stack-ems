package streamProblems;

import java.util.HashMap;
import java.util.Map;

public class SecondLeastSalaryUsingHashMapStreams {

	public static void main(String[] args) {
		// Create a HashMap with names as keys and salaries as values
		Map<String, Integer> salaryMap = new HashMap<>();
		salaryMap.put("Alice", 3000);
		salaryMap.put("Bob", 2500);
		salaryMap.put("Charlie", 4000);
		salaryMap.put("David", 2000);
		salaryMap.put("Eve", 3500);

		// Find the second least salary person and their salary
		Map.Entry<String, Integer> secondLeastEntry = salaryMap.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.skip(1) // Skip the first entry, which is the minimum
				.findFirst().orElse(null);

		if (secondLeastEntry != null) {
			System.out.println("Second least salary person: " + secondLeastEntry.getKey());
			System.out.println("Salary: " + secondLeastEntry.getValue());
		} else {
			System.out.println("No second least salary found.");
		}

	}

}
