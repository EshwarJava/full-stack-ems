package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateBO;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface CandidateRepository extends CrudRepository<CandidateBO, Integer>, JpaSpecificationExecutor {
    Optional<CandidateBO> findByResumeId(String resumeId);

    @Query(value = "select c.source_channel_id, count(c.id) from candidate c group by c.source_channel_id", nativeQuery = true)
    List<Tuple> getCandidateCountBySourceChannel();

    @Query(value = "select csl.name as status, count(c.id) from candidate c inner join sjd_candidate_info sci on c.id = sci.candidate_id inner join candidate_status_lookup csl on sci.candidate_status_id = csl.id where sci.sjd_id in ?1 group by csl.name", nativeQuery = true)
    List<Tuple> getCandidateCountByStatus(List<Integer> sjdId);

    List<CandidateBO> findByResumeIdIn(List<String> resumeIds);

    @Query(value = "select csl.name as status, count(c.id) from candidate c inner join sjd_candidate_info sci on c.id = sci.candidate_id inner join candidate_status_lookup csl on sci.candidate_status_id = csl.id where sci.sjd_id in ?1 and sci.created_on >= ?2 and sci.created_on <= ?3 and sci.is_migrated is null group by csl.name", nativeQuery = true)
    List<Tuple> filterCandidateCountByStatus(@Param("sjdId") List<Integer> sjdId, @Param("fromDate") Date fromDate,
                                             @Param("toDate") Date toDate);
}
