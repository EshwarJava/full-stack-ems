INSERT INTO public.answer_type_lookup ("name") VALUES('Multiline');
INSERT INTO public.answer_type_lookup ("name") VALUES('Rating');
INSERT INTO public.answer_type_lookup ("name") VALUES('Yes or No');

INSERT INTO public.questionnaire_type_lookup ("name") VALUES('General');
INSERT INTO public.questionnaire_type_lookup ("name") VALUES('Technical');

INSERT INTO public.qualification_lookup ("name") VALUES('Degree');
INSERT INTO public.qualification_lookup ("name") VALUES('BTech');
INSERT INTO public.qualification_lookup ("name") VALUES('MBA');
INSERT INTO public.qualification_lookup ("name") VALUES('MCA');
INSERT INTO public.qualification_lookup ("name") VALUES('Inter');
INSERT INTO public.qualification_lookup ("name") VALUES('MTech');
INSERT INTO public.qualification_lookup ("name") VALUES('SCC');
INSERT INTO public.qualification_lookup ("name") VALUES('PMP/SCRUM Certification');
INSERT INTO public.qualification_lookup ("name") VALUES('B.tech/M.tech/MCA/MSC');
INSERT INTO public.qualification_lookup ("name") VALUES('BFA');
INSERT INTO public.qualification_lookup ("name") VALUES('BA Journalism');

INSERT INTO public.priorities_lookup ("name") VALUES('Low');
INSERT INTO public.priorities_lookup ("name") VALUES('Medium');
INSERT INTO public.priorities_lookup ("name") VALUES('High');

INSERT INTO public.pay_type_lookup ("name") VALUES('Hourly');
INSERT INTO public.pay_type_lookup ("name") VALUES('Annualy');

INSERT INTO public.client_lookup ("name") VALUES('PeopleTech');

INSERT INTO public.job_type_lookup ("name") VALUES('Full Time');
INSERT INTO public.job_type_lookup ("name") VALUES('Part Time');
INSERT INTO public.job_type_lookup ("name") VALUES('Internship');
INSERT INTO public.job_type_lookup ("name") VALUES('Contract');
INSERT INTO public.job_type_lookup ("name") VALUES('Remote');


INSERT INTO public.domain_lookup ("name") VALUES('Cloud and App Modernization');
INSERT INTO public.domain_lookup ("name") VALUES('Mobility & Embedded');
INSERT INTO public.domain_lookup ("name") VALUES('ERP');
INSERT INTO public.domain_lookup ("name") VALUES('Modern Workspace');
INSERT INTO public.domain_lookup ("name") VALUES('IT Support');
INSERT INTO public.domain_lookup ("name") VALUES('HR');
INSERT INTO public.domain_lookup ("name") VALUES('Web Development');
INSERT INTO public.domain_lookup ("name") VALUES('Recruitment');
INSERT INTO public.domain_lookup ("name") VALUES('Website Content Management');
INSERT INTO public.domain_lookup ("name") VALUES('Application Services');
INSERT INTO public.domain_lookup ("name") VALUES('Application Services - Specialized');
INSERT INTO public.domain_lookup ("name") VALUES('Business unit / Customer support');
INSERT INTO public.domain_lookup ("name") VALUES('Cloud computing');
INSERT INTO public.domain_lookup ("name") VALUES('Computer operations');
INSERT INTO public.domain_lookup ("name") VALUES('Corporate functions');
INSERT INTO public.domain_lookup ("name") VALUES('Data management');
INSERT INTO public.domain_lookup ("name") VALUES('Infrastructure management');
INSERT INTO public.domain_lookup ("name") VALUES('Information Technology Infrastructure Library');
INSERT INTO public.domain_lookup ("name") VALUES('IT Security');
INSERT INTO public.domain_lookup ("name") VALUES('IT Technology Tools');
INSERT INTO public.domain_lookup ("name") VALUES('Network Services');
INSERT INTO public.domain_lookup ("name") VALUES('Program/Project management');
INSERT INTO public.domain_lookup ("name") VALUES('Social Networking Services');
INSERT INTO public.domain_lookup ("name") VALUES('Systems management');
INSERT INTO public.domain_lookup ("name") VALUES('Technology Dev and Architecture');
INSERT INTO public.domain_lookup ("name") VALUES('Business Analytics');
INSERT INTO public.domain_lookup ("name") VALUES('Mobile Computing');
INSERT INTO public.domain_lookup ("name") VALUES('Machine learning & Artificial intelligence');
INSERT INTO public.domain_lookup ("name") VALUES('RPA');
INSERT INTO public.domain_lookup ("name") VALUES('Designing')

INSERT INTO public.user_companies_lookup ("name") VALUES('People Tech Group');

INSERT INTO public.user_departments_lookup ("name") VALUES('ERP');

INSERT INTO public.user_operations_lookup ("name") VALUES('Indian Operations');
INSERT INTO public.user_operations_lookup ("name") VALUES('US Operations');

INSERT INTO public.user_roles_lookup ("name") VALUES('admin');
INSERT INTO public.user_roles_lookup ("name") VALUES('lead');
INSERT INTO public.user_roles_lookup ("name") VALUES('recruiter');
INSERT INTO public.user_roles_lookup ("name") VALUES('evaluator');

INSERT INTO public.skills_lookup ("name") VALUES('Java');
INSERT INTO public.skills_lookup ("name") VALUES('React');

INSERT INTO public.source_channel_lookup ("name") VALUES('Naukri');
INSERT INTO public.source_channel_lookup ("name") VALUES('Monster');
INSERT INTO public.source_channel_lookup ("name") VALUES('LinkedIn');
INSERT INTO public.source_channel_lookup ("name") VALUES('Others');
INSERT INTO public.source_channel_lookup ("name") VALUES('Dice');
INSERT INTO public.source_channel_lookup ("name") VALUES('Indeed');
INSERT INTO public.source_channel_lookup ("name") VALUES('Reference');

INSERT INTO public.candidate_status_lookup ("name") VALUES('New');
INSERT INTO public.candidate_status_lookup ("name") VALUES('QC Rated');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Profiler Rated');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Online Test Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Online Test cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-1 Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-1 cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-2 Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-2 cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-3 Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-3 cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-4 Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-4 cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-5 Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Tech Interview-5 cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Client Interview Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Client Interview Cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('HR Interview Scheduled');
INSERT INTO public.candidate_status_lookup ("name") VALUES('HR Interview Cleared');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Document Verification Started');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Document Verification Completed');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Offer approved');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Offer released');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Offer accepted');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Joined');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Rejected');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Not Interested');
INSERT INTO public.candidate_status_lookup ("name") VALUES('Callback');
INSERT INTO public.candidate_status_lookup ("name") VALUES('On Hold');

INSERT INTO public.sjd_status_lookup ("name") VALUES('Draft');
INSERT INTO public.sjd_status_lookup ("name") VALUES('New');
INSERT INTO public.sjd_status_lookup ("name") VALUES('In Progress');
INSERT INTO public.sjd_status_lookup ("name") VALUES('On Hold');
INSERT INTO public.sjd_status_lookup ("name") VALUES('Completed');

INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CANDIDATE_CREATED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CANDIDATE_TAGGED_TO_SJD');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CANDIDATE_UNTAGGED_FROM_SJD');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('RESUME_UPDATED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CANDIDATE_STATUS_CHANGED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CANDIDATE_DETAILS_UPDATED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('COMMENTS_ADDED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('QC_RATING_ADDED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('FEEDBACK_ADDED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('PROFILER_RATING_ADDED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CANDIDATE_REJECTED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('QUESTIONNAIRE_ANSWER_UPDATED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('INTERVIEW_SCHEDULED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('INTERVIEW_RESCHEDULED');
INSERT INTO public.candidate_event_types_lookup ("name") VALUES('CALLBACK_ADDED');

INSERT INTO public.sjd_event_types_lookup ("name") VALUES('SJD_CREATED');
INSERT INTO public.sjd_event_types_lookup ("name") VALUES('SJD_DETAILS_UPDATED');
INSERT INTO public.sjd_event_types_lookup ("name") VALUES('CANDIDATE_ADDED');
INSERT INTO public.sjd_event_types_lookup ("name") VALUES('CANDIDATE_REMOVED');
INSERT INTO public.sjd_event_types_lookup ("name") VALUES('SJD_STATUS_CHANGED');
INSERT INTO public.sjd_event_types_lookup ("name") VALUES('QUESTIONNAIRE_ATTACHED');

INSERT INTO public.user_details (employee_code, first_name, last_name, email, phone_number, company_id, department_id, operation_id, is_active, is_locked, created_by, created_on, modified_by, modified_on)
    VALUES('5689', 'Manikandan', 'Uthaman', 'manikandan.uthaman@peopletech.com', '7502506075', 1, 1, 1, true, false, 1, now(), 1, now());
INSERT INTO public.user_details (employee_code, first_name, last_name, email, phone_number, company_id, department_id, operation_id, is_active, is_locked, created_by, created_on, modified_by, modified_on)
    VALUES('5688', 'Shubham', 'Singh', 'shubham.singh@peopletech.com', '', 1, 1, 1, true, false, 1, now(), 1, now());

INSERT INTO public.user_credentials (user_id, username, "password")
    VALUES(1, 'manikandan.uthaman@peopletech.com', 'ENCRYPTED_PWD');
INSERT INTO public.user_credentials (user_id, username, "password")
    VALUES(2, 'shubham.singh@peopletech.com', 'ENCRYPTED_PWD');

INSERT INTO public.user_role_mapping (user_id, role_id) VALUES(1, 1);
INSERT INTO public.user_role_mapping (user_id, role_id) VALUES(2, 1);

INSERT INTO public.sjd(
	name, description, domain_id, priority_id, job_location, operation_id, client_id, open_positions, job_type_id, pay_type_id, pay_rate, project_duration, experience_level, keywords, target_companies, evaluation_criteria, qualification_id, notice_period, is_client_round, no_of_tech_interview, is_online_test, status_id, created_by_id, created_on, modified_by_id, modified_on)
	VALUES ('New SJD', 'SJD Description', 1, 1, 'Hyderabad', 1, 1, 10, 1, 1, 50, 24, 5, 'Java,React', 'Infosys,TCS', 'Coding test', 1, 30, true, 2, true, 1, 1, now(), 1, now());

INSERT INTO public.candidate ("name", candidate_status_id, email, phone_number, "location", notice_period_days, experience_years, experience_months, profile_summary, resume_id, resume_filename, source_channel_id, domain_expertise_id, present_role, current_ctc, expected_ctc, address, areas_to_relocate, visa_type, visa_status, visa_validity, created_by_id, created_on, modified_by_id, modified_on)
    VALUES('Manikandan', 1, 'manikandan.mit@outloook.com', '7502506075', 'Chennai, India', 30, 8, 0, 'Profile Summary', 1, 'Manikandan_Resume.pdf', 1, 1, 'Software Developer', 15.00, 20.00, 'Manapakkam, Chennai', '', '', '', '', 1, now(), 1, now());

INSERT INTO public.candidate_skills_mapping (candidate_id, skill_id) VALUES(1, 1);
INSERT INTO public.candidate_skills_mapping (candidate_id, skill_id) VALUES(1, 2);

INSERT INTO public.candidate_certification (candidate_id,certification_name,issued_by,certification_year) VALUES (1,'AWS','Amazon',2022);

INSERT INTO public.candidate_education (candidate_id,institution_name,"location",qualification,"domain",start_date,end_date)
    VALUES (1,'Anna University','Chennnai','M.E','EIE','2012-08-01','2014-04-01');
INSERT INTO public.candidate_education (candidate_id,institution_name,"location",qualification,"domain",start_date,end_date)
	VALUES (1,'Anna University','Chennnai','B.E','EEE','2008-08-01','2012-04-01');

INSERT INTO public.candidate_employment (candidate_id,company_name,start_date,end_date,responsibilities,"location")
    VALUES (1,'Walmart','2020-07-12','2023-01-10','Design and development of software applications','Chennai');

