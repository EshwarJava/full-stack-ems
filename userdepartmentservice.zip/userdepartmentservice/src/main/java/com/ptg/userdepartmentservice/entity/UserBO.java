package com.ptg.userdepartmentservice.entity;

import lombok.*;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@ToString(exclude = "departmentBO")
@Table(name = "user_table", schema = "public")
public class UserBO {
    @Id
    @SequenceGenerator(name = "user_sequence_generator", sequenceName = "user_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence_generator")
    @Column(name = "user_id")
    private int userId;

    @Column(name = "name")
    private String name;

    @Column(name = "date_of_birth")
    private String dob;

    @Column(name = "age")
    private int age;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "dept_id", referencedColumnName = "dept_id")
    DepartmentBO departmentBO;

}
