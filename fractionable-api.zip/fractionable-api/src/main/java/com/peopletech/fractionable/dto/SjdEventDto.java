package com.peopletech.fractionable.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SjdEventDto {
    private Integer id;
    private Integer sjdId;
    private Integer eventTypeId;
    private String description;
    private String createdBy;
    private Date createdOn;
}
