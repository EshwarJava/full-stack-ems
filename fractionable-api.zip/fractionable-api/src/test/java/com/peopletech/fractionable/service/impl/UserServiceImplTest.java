package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.exception.InvalidCredentialsException;
import com.peopletech.fractionable.repository.UserCredentialRepository;
import com.peopletech.fractionable.repository.UserDetailsRepository;
import com.peopletech.fractionable.repository.UserRoleRepository;
import com.peopletech.fractionable.service.UserService;
import com.peopletech.fractionable.util.MicrosoftTokenVerifierUtil;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {
    @Mock
    private UserDetailsRepository userDetailsRepository;

    @Mock
    private UserCredentialRepository userCredentialRepository;

    @Mock
    private UserRoleRepository userRoleRepository;


    private UserService userService;

    @Mock
    private MicrosoftTokenVerifierUtil microsoftTokenVerifierUtil;

    @BeforeEach
    public void setup() {
        userService = new UserServiceImpl(userDetailsRepository, userCredentialRepository, new DozerBeanMapper(), userRoleRepository, microsoftTokenVerifierUtil);
    }

    @Test
    public void shouldFindById() {
        when(userDetailsRepository.findById(anyInt())).thenReturn(Optional.of(new UserDetailsBO()));
        assertTrue(userService.findByUserId(1) instanceof UserDetailsBO);
    }

    @Test
    public void shouldThrowExceptionWhenNotFoundById() {
        when(userDetailsRepository.findById(anyInt())).thenReturn(Optional.ofNullable(null));
        assertThrowsExactly(NoSuchElementException.class, () -> userService.findByUserId(1));
    }


    @Test
    @DisplayName("should throw InvalidCredentialsException exception when access token is invalid")
    public void authenticateTokenFail() {
        when(microsoftTokenVerifierUtil.verifyToken(anyString())).thenReturn(null);
        assertThrowsExactly(InvalidCredentialsException.class, () -> userService.authenticateToken("test"));
    }

    @Test
    @DisplayName("should successfully return user details when token is valid")
    public void authenticateTokenSuccess() {
        when(microsoftTokenVerifierUtil.verifyToken(anyString())).thenReturn("test@peopletech.com");
        when(userDetailsRepository.findByEmailIgnoreCase(anyString())).thenReturn(Optional.of(new UserDetailsBO()));
        assertTrue(userService.authenticateToken("token") instanceof UserDetailsBO);
    }

    @Test
    @DisplayName("should create user with proper default values")
    public void createUser() {
        UserDetailsDto userDetailsDto = new UserDetailsDto();
        userDetailsDto.setFirstName("fname");
        ReflectionTestUtils.setField(userService, "defaultPwd", "test", String.class);
        when(userDetailsRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);
        when(userCredentialRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);
        UserDetailsDto result = userService.createUser(userDetailsDto, 1);
        assertEquals(result.getFirstName(), userDetailsDto.getFirstName());
        assertTrue(result.getActive());
        assertFalse(result.getLocked());
    }
}
