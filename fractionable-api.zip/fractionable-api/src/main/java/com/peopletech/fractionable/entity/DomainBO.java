package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "domain_lookup")
public class DomainBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "domain_lookup_id_generator")
    @SequenceGenerator(name = "domain_lookup_id_generator", sequenceName = "domain_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
