package com.exams;

import java.util.HashSet;

public class HappyNumberHashMap {

	public static void main(String[] args) {
		boolean res = isHappy(19);
		System.out.println(res);
	}

	public static boolean isHappy(int n) {
		if (n == 1) {
			return true;
		}
		HashSet<Integer> set = new HashSet<Integer>();
		while (!set.contains(n)) {
			set.add(n);
			int sumOfSquares = sumOfSquares(n);
			if (sumOfSquares == 1) {
				return true;
			}
			n = sumOfSquares;
		}
		return false;
	}

	private static int sumOfSquares(int n) {
		int sum = 0;
		while (n != 0) {
			int re = n % 10;
			sum = sum + re * re;
			n = n / 10;
		}
		return sum;
	}

}
