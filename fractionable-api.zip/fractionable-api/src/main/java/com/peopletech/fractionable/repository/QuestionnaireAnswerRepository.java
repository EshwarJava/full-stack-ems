package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.QuestionnaireAnswersBO;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface QuestionnaireAnswerRepository extends CrudRepository<QuestionnaireAnswersBO, Integer> {

    Optional<List<QuestionnaireAnswersBO>> getAllBySjdIdAndCandidateId(Integer sjdId, Integer candidateId);
}
