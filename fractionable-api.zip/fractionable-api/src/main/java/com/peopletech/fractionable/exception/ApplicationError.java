package com.peopletech.fractionable.exception;

import lombok.Data;

import java.io.Serializable;

@Data
public class ApplicationError implements Serializable {

    private static final long serialVersionUID = 1L;
    private String message;
    public ApplicationError(String message) {
        this.message = message;
    }
}
