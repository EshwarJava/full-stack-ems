package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public class QuestionnaireAnswerDto {
    private Integer id;
    private Integer sjdId;
    private Integer questionnaireId;
    private Integer questionId;
    private Integer candidateId;
    private String answer;
}
