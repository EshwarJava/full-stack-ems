package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.constants.CandidateEventType;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.SjdQuestionnaireRequestDto;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.entity.compoundkey.SjdQuestionnaireID;
import com.peopletech.fractionable.repository.QuestionRepository;
import com.peopletech.fractionable.repository.QuestionnaireAnswerRepository;
import com.peopletech.fractionable.repository.QuestionnaireRepository;
import com.peopletech.fractionable.repository.SjdQuestionnaireMappingRepository;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.service.QuestionnaireService;
import com.peopletech.fractionable.service.SjdEventService;
import com.peopletech.fractionable.util.CommonUtil;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class QuestionnaireServiceImpl implements QuestionnaireService {

    @Autowired
    SjdQuestionnaireMappingRepository sjdQuestionnaireMappingRepository;

    @Autowired
    QuestionnaireRepository questionnaireRepository;

    @Autowired
    QuestionRepository questionRepository;

    @Autowired
    SjdEventService sjdEventService;

    @Autowired
    QuestionnaireAnswerRepository questionnaireAnswerRepository;

    @Autowired
    CandidateEventService candidateEventService;

    @Autowired
    CommonUtil commonUtil;

    @Autowired
    DozerBeanMapper mapper;


    @Override
    public List<QuestionnaireDto> getAllQuestionnaire() {
        Iterable<QuestionnaireBO> questionnaireList = questionnaireRepository.findAll();
        return StreamSupport
                .stream(questionnaireList.spliterator(), false)
                .map(q -> mapper.map(q, QuestionnaireDto.class))
                .toList();
    }

    @Override
    public List<QuestionnaireDto> getAllQuestionnaireByType(Integer questionnaireTypeId, List<LookupDto> skills) {
        List<QuestionnaireBO> questionnaire;
        if (CollectionUtils.isEmpty(skills)) {
            questionnaire = questionnaireRepository.findAllByQuestionnaireType(new QuestionnaireTypeBO(questionnaireTypeId, null));
        } else {
            questionnaire = questionnaireRepository.findByQuestionnaireTypeAndSkillsIn(
                    new QuestionnaireTypeBO(questionnaireTypeId, null),
                    skills.stream().map(skill -> mapper.map(skill, SkillBO.class)).collect(Collectors.toList())
            );
        }
        return commonUtil.mapItreable(questionnaire, QuestionnaireDto.class);
    }

    @Override
    public QuestionnaireDto getQuestionnaireById(Integer id) {
        QuestionnaireBO questionnaire = questionnaireRepository
                .findById(id)
                .orElseThrow(() -> new NoSuchElementException(String.format("Questionnaire with id %s not found", id)));
        QuestionnaireDto questionnaireDto = mapper.map(questionnaire, QuestionnaireDto.class);
        questionnaireDto.setSjdId(
                sjdQuestionnaireMappingRepository
                        .findByQuestionnaireId(id)
                        .stream()
                        .map(q -> q.get(0, Integer.class))
                        .toList());
        return questionnaireDto;
    }

    @Override
    public Integer saveQuestionnaire(QuestionnaireDto questionnaire, Integer userId) {
        questionnaire.setCreatedBy(UserDetailsDto.builder().id(userId).build());
        questionnaire.setCreatedOn(new Date());
        QuestionnaireBO questionnaireEntity = questionnaireRepository
                .save(mapper.map(questionnaire, QuestionnaireBO.class));
        return questionnaireEntity.getId();
    }

    @Override
    public Integer updateQuestionnaire(QuestionnaireDto questionnaire, Integer userId) {
//        questionnaire.setCreatedBy(UserDetailsDto.builder().id(userId).build());
//        questionnaire.setCreatedOn(new Date());
        QuestionnaireBO questionnaireEntity = questionnaireRepository
                .save(mapper.map(questionnaire, QuestionnaireBO.class));
        return questionnaireEntity.getId();
    }

    @Override
    public Integer saveQuestion(QuestionDto question) {
        QuestionBO questionEntity = questionRepository
                .save(mapper.map(question, QuestionBO.class));
        return questionEntity.getId();
    }

    @Override
    public void deleteQuestion(Integer id) {
        questionRepository.deleteById(id);
    }

    @Override
    public void tagQuestionnaireToSjd(SjdQuestionnaireRequestDto request, Integer userId) {
        sjdQuestionnaireMappingRepository.save(
                new SjdQuestionnaireMappingBO(
                        new SjdQuestionnaireID(request.getSjdId(), request.getQuestionnaireId())
                )
        );
        sjdEventService.addEvent(request.getSjdId(), userId, AppConstants.SjdEventTypes.QUESTIONNAIRE_ATTACHED.name(), String.valueOf(request.getQuestionnaireId()));

    }

    @Override
    public List<QuestionnaireAnswerDto> getQuestionnaireAnswers(Integer sjdId, Integer candidateId) {
        List<QuestionnaireAnswersBO> answersBO = questionnaireAnswerRepository.getAllBySjdIdAndCandidateId(sjdId, candidateId).orElse(new ArrayList<>());
        return commonUtil.mapItreable(answersBO, QuestionnaireAnswerDto.class);
    }

    @Override
    public void saveQuestionnaireAnswers(List<QuestionnaireAnswerDto> answers, Integer userId) {
        List<QuestionnaireAnswersBO> answersBOs = commonUtil.mapItreable(answers, QuestionnaireAnswersBO.class);
        questionnaireAnswerRepository.saveAll(answersBOs);
        CandidateEventDto event = new CandidateEventDto();
        event.setSjdId(answers.get(0).getSjdId());
        event.setCandidateId(answers.get(0).getCandidateId());

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(answers.get(0).getSjdId())
                        .candidateId(answers.get(0).getCandidateId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.QUESTIONNAIRE_ANSWER_UPDATED
                                .name()).getId())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }
}
