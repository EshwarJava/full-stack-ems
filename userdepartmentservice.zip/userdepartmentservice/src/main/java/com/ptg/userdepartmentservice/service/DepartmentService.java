package com.ptg.userdepartmentservice.service;

import com.ptg.userdepartmentservice.dto.DepartmentUpdateDTO;
import com.ptg.userdepartmentservice.entity.DepartmentBO;

import java.util.List;


public interface DepartmentService {
    DepartmentBO insertDepartment(DepartmentBO departmentBO);

    DepartmentBO getDepartmentByDeptId(Integer id);

    List<DepartmentBO> getAllDepartments();

    DepartmentBO updateDepartmentofDeptId(DepartmentUpdateDTO departmentUpdateDTO, Integer deptId);
}
