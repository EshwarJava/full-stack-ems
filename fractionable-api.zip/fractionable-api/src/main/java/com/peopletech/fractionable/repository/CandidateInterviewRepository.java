package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateInterviewBO;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CandidateInterviewRepository extends CrudRepository<CandidateInterviewBO, Integer> {
    List<CandidateInterviewBO> findBySjdIdAndCandidateId(Integer sjdId, Integer candidateId);

    @Query(value = "select c.id as candidate_id, c.name as candidate_name, s.id as sjd_id, s.name as sjd_name, ci.interview_level, ud.id as evaluator_id, CONCAT(ud.first_name,' ',ud.last_name) as evaluator_name, ci.start_time, ci.end_time, ci.created_by_id from candidate_interview ci inner join sjd s on ci.sjd_id = s.id inner join candidate c on ci.candidate_id = c.id inner join user_details ud on ci.evaluator_id = ud.id where ci.interview_feedback is null and s.id in ?1 order by ci.start_time asc", nativeQuery = true)
    List<Tuple> getActiveInterviews(List<Integer> sjdIds);

    @Query(value = "select c.id as candidate_id, c.name as candidate_name, s.id as sjd_id, s.name as sjd_name, ci.interview_level, ci.start_time, ci.end_time, ci.created_by_id, CONCAT(ud.first_name,' ',ud.last_name) as recruiter_name, ci.is_recommended as result from candidate_interview ci inner join sjd s on ci.sjd_id = s.id inner join candidate c on ci.candidate_id = c.id inner join user_details ud on ci.created_by_id = ud.id where ci.evaluator_id = ?1 order by ci.start_time asc", nativeQuery = true)
    List<Tuple> getMyInterviews(Integer userId);

}
