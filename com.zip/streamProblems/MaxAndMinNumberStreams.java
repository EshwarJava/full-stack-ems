package streamProblems;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;

public class MaxAndMinNumberStreams {

	public static void main(String[] args) {
		List <Integer> nums = Arrays.asList(1, 17, 54, 14, 14, 33, 45, -11);
	    System.out.println("Original list of numbers: " + nums);
	    // Find the maximum value
	    Integer max_val = nums.stream()
	      .max(Integer::compare)
	      .orElse(null);

	    // Find the minimum value
	    Integer min_val = nums.stream()
	      .min(Integer::compare)
	      .orElse(null);
	    
	    IntSummaryStatistics statistics = nums.stream().mapToInt(i -> i.intValue()).summaryStatistics();
	    statistics.getMax();
	    statistics.getMin();
	    statistics.getCount();
	    statistics.getAverage();

	    System.out.println("\nMaximum value of the said list: " + max_val);
	    System.out.println("\nMinimum value of the said list: " + min_val);

	}

}
