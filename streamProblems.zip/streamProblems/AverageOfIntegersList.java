package streamProblems;

import java.util.Arrays;
import java.util.List;

public class AverageOfIntegersList {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(5, 5, 3, 3);
		//mapToDouble() It is used to transform each element of the stream into a double
		// i-> i.doubleValue() explicitly converting Integer to Double
		double f = list.stream().mapToDouble(i -> i.doubleValue()).average().orElse(0.0);
		System.out.println(f);
	}
}
