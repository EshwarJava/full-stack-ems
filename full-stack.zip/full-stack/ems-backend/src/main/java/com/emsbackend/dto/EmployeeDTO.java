package com.emsbackend.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {
    Long empId;

    String firstName;

    String lastName;

    String email;
}
