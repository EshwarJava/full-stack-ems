package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
public class CandidateDto {

    private Integer id;
    private String name;
    private String email;
    private String phoneNumber;
    private String location;
    private Integer noticePeriod;
    private Float experience;
    private String resumeId;
    private Integer sourceChannel;
    private Integer domain;
    private String currentRole;
    private String currentCtc;
    private String expectedCtc;
    private String linkedInUrl;
    private String visaType;
    private String visaStatus;
    private String visaValidity;
    private List<CandidateEducationDto> educationDetails;
    private List<CandidateCertificationDto> certificationDetails;
    private List<CandidateEmploymentDto> employmentDetails;
    private List<CandidateDocumentDto> documents;
    private List<LookupDto> skills = new ArrayList<>();
    private List<CandidateInterviewDto> interview;
    private List<CandidateEventDto> events = new ArrayList<>();
    private List<SjdCandidateInfoDto> sjdCandidateInfo = new ArrayList<>();
    private String additionalInfo;
    private Integer operations;
    private Integer currentCtcFrequency;
    private Integer expectedCtcFrequency;
    private Integer createdBy;
    private Date createdOn;
    private Integer modifiedBy;
    private Date modifiedOn;
    private Boolean aiCheckbox;
    private Boolean isMigrated;
}
