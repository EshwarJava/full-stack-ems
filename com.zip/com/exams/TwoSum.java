package com.exams;

import java.util.HashMap;

public class TwoSum {

	public static void main(String[] args) {

		int[] arr = new int[] { 2, 7, 11, 15 };
		int target = 9;
		int[] indexes = twoSum(arr, target);
		for (int i : indexes) {
			System.out.println(i);
		}
	}

	private static int[] twoSum(int[] arr, int target) {
		int[] res = new int[2];
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < arr.length; i++) {
			if (map.containsKey(target - arr[i])) {
				res[0] = map.get(target - arr[i]);
				res[1] = i;
			} else {
				map.put(arr[i], i);
			}
		}
		return res;
	}
}
