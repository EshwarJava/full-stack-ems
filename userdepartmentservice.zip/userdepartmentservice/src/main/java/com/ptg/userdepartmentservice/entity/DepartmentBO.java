package com.ptg.userdepartmentservice.entity;

import jakarta.persistence.Column;
import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Data
@Table(name = "department_table", schema = "public")
public class DepartmentBO {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "department_generator")
    @SequenceGenerator(name = "department_generator", sequenceName = "department_sequence", allocationSize = 1)
    @Column(name = "dept_id")
    private int id;

    @Column(name = "dept_name")
    private String deptName;

}
