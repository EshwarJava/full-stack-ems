package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.SjdCandidateInfoDto;
import com.peopletech.fractionable.dto.SjdDto;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;

import java.util.List;

public interface SjdService {
    SjdDto getSjd(int id);

    SjdDto addSjd(SjdDto sjd, Integer userId);

    SjdDto updateSjd(SjdDto sjd, Integer userId);

    List<SjdDto> getAllSjd(Integer userId);

    void tagCandidateToSjd(TagCandidateRequest request, Integer userId);

    void unTagCandidateFromSjd(SjdCandidateInfoDto request, Integer userId);

}
