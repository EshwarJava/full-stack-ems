package com.ptg.userdepartmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserdepartmentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
