package com.peopletech.fractionable.entity.compoundkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserRoleID implements Serializable {
    private Integer user;
    private Integer role;
}
