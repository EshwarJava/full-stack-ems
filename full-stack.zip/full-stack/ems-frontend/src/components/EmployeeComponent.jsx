import React, { useState } from 'react'

const EmployeeComponent = () => {
    
    const [firstName, setFirstname] = useState('');
    const [lastName, setlastName] = useState('');
    const [email, setEmail] = useState('');

    function handleFirstName(e){
        setFirstname(e.target.value)
    }

    function handleLastName(e){
        setlastName(e.target.value)
    }

    function handleEmail(e){
        setEmail(e.target.value)
    }

    function saveEmployee(e){
        e.preventDefault();
        const employee = {firstName, lastName, email}
        console.log(employee);

    }

  return (
    <div className='container'>
      <div className='row'>
        <div className='card col-md-6'> 
            <h2 className='text-center'>Add Employee</h2>
            <div className='card-body'>
                <form>
                    <div className='form-group mb-2'>
                        <label className='form-label'>Employee First Name:</label>
                        <input
                         type="text"
                         placeholder='Enter Employee First Name'
                         className="form-control"
                         name="firstName"
                         value={firstName}
                         onChange={handleFirstName}
          />
                    </div>
                    <div className='form-group mb-2'>
                        <label className='form-label'>Employee Last Name:</label>
                        <input
                         type="text"
                         placeholder='Enter Employee LastName'
                         className="form-control"
                         name="lastName"
                         value={lastName}
                         onChange={handleLastName}
          />
                    </div>
                    <div className='form-group mb-2'>
                        <label className='form-label'>Employee Email:</label>
                        <input
                         type="text"
                         placeholder='Enter Employee Email'
                         className="form-control"
                         name="email"
                         value={email}
                         onChange={handleEmail}
          />
                    </div>
                    <button className='btn btn-success' onClick={saveEmployee}>Submit</button>
                </form>

            </div>

        </div>
      </div>
    </div>
  )
}

export default EmployeeComponent
