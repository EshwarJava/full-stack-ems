package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum RatingType {
    QC_RATING("qcRating"),
    PROFILER_RATING("profilerRating");

    private final String type;

    RatingType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public static RatingType get(String type) {
        return Arrays.stream(RatingType.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Rating type is invalid"));
    }

}
