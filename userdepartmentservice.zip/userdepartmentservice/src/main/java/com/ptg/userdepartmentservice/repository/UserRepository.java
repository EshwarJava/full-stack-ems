package com.ptg.userdepartmentservice.repository;

import com.ptg.userdepartmentservice.entity.UserBO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserBO, Integer> {

    List<UserBO> findByName(String name);

    List<UserBO> findByAge(int age);

    @Query(value = "SELECT u.* FROM user_table u JOIN department_table d ON u.dept_id = d.dept_id where d.dept_id = ?1",
            nativeQuery = true)
    List<UserBO> getListOfUsersWithDeptID(Integer id);


}
