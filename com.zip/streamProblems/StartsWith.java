package streamProblems;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StartsWith {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("bcJKGljh", "vKJUuj", "hjkgbuFUY", "bcdj");
		List<String> startsWithList =list.stream().filter(str -> str.startsWith("b")).collect(Collectors.toList());
		System.out.println(startsWithList);
	}
}
