package com.exams;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class longestConsecutiveSequenceHashing {

	public static void main(String[] args) {
		int[] nums = new int[] { 100, 4, 200, 1, 3, 2 };
		System.out.println(longestConsecutive(nums));

	}

	public static int longestConsecutive(int[] nums) {
		if (nums.length == 0 || nums == null) {
			return 0;
		}
		int max = 1;
		HashSet<Integer> set = new HashSet<Integer>();
		for (int i : nums) {
			set.add(i);
		}
		for (int i : nums) {
			int count = 1;
			int left = i - 1;
			int right = i + 1;
			 List<Integer> toRemove = new ArrayList<>();
			while (set.contains(left)) {
				count++;
				toRemove.add(left);
				left--;
			}
			while (set.contains(right)) {
				count++;
				toRemove.add(left);
				right++;
			}
			for (int numToRemove : toRemove) {
				set.remove(numToRemove);
			}
			max = Math.max(max, count);
		}
		return max;

	}

}
