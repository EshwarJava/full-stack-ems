package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.PayTypeBO;
import org.springframework.data.repository.CrudRepository;

public interface PayTypeRepository extends CrudRepository<PayTypeBO, Integer> {
}
