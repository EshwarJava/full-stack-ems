package com.peopletech.fractionable.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.dozer.CustomConverter;

import java.util.HashMap;
import java.util.Map;

public class LookupDozerConverter implements CustomConverter {

    ObjectMapper mapper = new ObjectMapper();

    @Override
    public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
        if (destClass.equals(Integer.class)) {
            return (mapper.convertValue(source, Map.class)).get("id");
        } else if (sourceClass.equals(Integer.class)) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", source);
            return mapper.convertValue(map, destClass);
        }
        return destination;
    }
}