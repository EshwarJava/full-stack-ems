package com.exams;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

public class IsoMorphicProblemHashMap {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String t = sc.nextLine();
		System.out.println(canConstruct(s, t));
	}
	
	private static boolean canConstruct(String s, String t) {
		Map<Character, Character> charMap = new HashMap<Character, Character>();
		 HashSet<Character> mapped = new HashSet<Character>();
		if(s.length()!=t.length()) {
			return false;
		}
		for(int i = 0; i<s.length(); i++) {
			Character c1 = s.charAt(i);
            Character c2 = t.charAt(i);
			char c;
			if(charMap.containsKey(c1)) {
				if(charMap.get(c1) != t.charAt(i)) {
					return false;
				}
			}
			else if(mapped.contains(c2)) {
					return false;
			}
			else {
			charMap.put(c1, c2);
			mapped.add(c2);
			}
		}
		return true;
	}

}
