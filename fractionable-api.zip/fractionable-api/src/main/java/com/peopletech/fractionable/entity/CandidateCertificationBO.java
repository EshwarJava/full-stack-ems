package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "candidate_certification")
public class CandidateCertificationBO {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_certification_id_generator")
    @SequenceGenerator(name = "candidate_certification_id_generator", sequenceName = "candidate_certification_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "candidate_id")
    private Integer candidateId;

    @Column(name = "certification_name")
    private String certificationName;

    @Column(name = "issued_by")
    private String issuedBy;

    @Column(name = "certification_year")
    private Integer certificationYear;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CandidateCertificationBO that = (CandidateCertificationBO) o;
        if (id != null || that.id != null)
            return Objects.equals(id, that.id);
        else
            return Objects.equals(candidateId, that.candidateId) && Objects.equals(certificationName, that.certificationName) && Objects.equals(issuedBy, that.issuedBy) && Objects.equals(certificationYear, that.certificationYear);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, candidateId, certificationName, issuedBy, certificationYear);
    }
}
