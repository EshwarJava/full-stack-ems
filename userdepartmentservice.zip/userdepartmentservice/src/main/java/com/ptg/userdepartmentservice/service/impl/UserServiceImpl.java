package com.ptg.userdepartmentservice.service.impl;

import com.ptg.userdepartmentservice.dto.UserWithDepartmentDTO;
import com.ptg.userdepartmentservice.entity.DepartmentBO;
import com.ptg.userdepartmentservice.entity.UserBO;
import com.ptg.userdepartmentservice.exception.UserNotfoundException;
import com.ptg.userdepartmentservice.repository.DepartmentRepository;
import com.ptg.userdepartmentservice.repository.UserRepository;
import com.ptg.userdepartmentservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public UserBO addUser(UserWithDepartmentDTO userWithDepartmentDTO) {
        DepartmentBO deptDepartmentBO = departmentRepository.findById(userWithDepartmentDTO.getDeptId()).get();
        UserBO userBO = UserBO.builder().name(userWithDepartmentDTO.getName()).
                dob(userWithDepartmentDTO.getDob()).age(userWithDepartmentDTO.getAge()).build();
        userBO.setDepartmentBO(deptDepartmentBO);
        userRepository.save(userBO);
        return userBO;
    }

    @Override
    public List<UserBO> getAllUserDetails() {
        return userRepository.findAll();
    }

    @Override
    public UserBO getUserAndDepartmentDetails(Integer userId) {
        return userRepository.findById(userId).orElseThrow(() -> new UserNotfoundException("User not found for Id" + userId));
    }

    @Override
    public List<UserBO> listOfUsersOfDepartment(Integer deptId) {
        return userRepository.getListOfUsersWithDeptID(deptId);
    }

    @Override
    public String deleteUser(Integer userId) {
        userRepository.deleteById(userId);
        return "User deleted with Id: " + userId;
    }


}