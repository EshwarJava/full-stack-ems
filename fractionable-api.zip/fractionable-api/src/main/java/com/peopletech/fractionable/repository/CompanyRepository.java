package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CompanyBO;
import org.springframework.data.repository.CrudRepository;

public interface CompanyRepository extends CrudRepository<CompanyBO, Integer> {
}
