package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.Date;

@Data
public class CandidateEmploymentDto {
    private Integer id;
    private String companyName;
    private String designation;
    private String location;
    private String responsibilities;
    private Date startDate;
    private Date endDate;
}
