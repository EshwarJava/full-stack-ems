package com.emsbackend.mapper;

import com.emsbackend.dto.EmployeeDTO;
import com.emsbackend.entity.Employee;

public class EmployeeMapper {

    public static Employee mapToEmployee(EmployeeDTO employeeDTO) {
        return new Employee(employeeDTO.getEmpId(), employeeDTO.getFirstName(), employeeDTO.getLastName(), employeeDTO.getEmail());
    }


    public static EmployeeDTO mapToEmployeeDTO(Employee employee) {
        return new EmployeeDTO(employee.getEmployeeId(), employee.getFirstName(), employee.getLastName(), employee.getEmail());
    }


}
