package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.util.LookupInfo;
import jakarta.annotation.PostConstruct;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class LookupServiceImpl implements LookupService {

    @Autowired
    private QualificationRepository qualificationRepository;

    @Autowired
    private PriorityRepository priorityRepository;

    @Autowired
    private PayTypeRepository payTypeRepository;

    @Autowired
    private JobTypeRepository jobTypeRepository;

    @Autowired
    private DomainRepository domainRepository;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private OperationsRepository operationsRepository;

    @Autowired
    private RolesRepository rolesRepository;

    @Autowired
    private SourceChannelRepository sourceChannelRepository;

    @Autowired
    private CandidateStatusRepository candidateStatusRepository;

    @Autowired
    private SjdStatusRepository sjdStatusRepository;

    @Autowired
    private CandidateEventTypesRepository candidateEventTypesRepository;

    @Autowired
    private SjdEventTypesRepository sjdEventTypesRepository;

    @Autowired
    private AnswerTypeRepository answerTypeRepository;

    @Autowired
    private QuestionnaireTypeRepository questionnaireTypeRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private SkillsRepository skillsRepository;

    @Autowired
    private DozerBeanMapper mapper;

    EnumMap<LookupType, LookupInfo> lookupMap = new EnumMap<>(LookupType.class);

    @PostConstruct
    public void initialize() {
        lookupMap.put(LookupType.QUALIFICATION, new LookupInfo(qualificationRepository, QualificationBO.class));
        lookupMap.put(LookupType.PRIORITY, new LookupInfo(priorityRepository, PriorityBO.class));
        lookupMap.put(LookupType.PAY_TYPE, new LookupInfo(payTypeRepository, PayTypeBO.class));
        lookupMap.put(LookupType.JOB_TYPE, new LookupInfo(jobTypeRepository, JobTypeBO.class));
        lookupMap.put(LookupType.DOMAIN, new LookupInfo(domainRepository, DomainBO.class));
        lookupMap.put(LookupType.COMPANY, new LookupInfo(companyRepository, CompanyBO.class));
        lookupMap.put(LookupType.DEPARTMENT, new LookupInfo(departmentRepository, DepartmentBO.class));
        lookupMap.put(LookupType.OPERATION, new LookupInfo(operationsRepository, OperationsBO.class));
        lookupMap.put(LookupType.ROLE, new LookupInfo(rolesRepository, RoleBO.class));
        lookupMap.put(LookupType.SOURCE_CHANNEL, new LookupInfo(sourceChannelRepository, SourceChannelBO.class));
        lookupMap.put(LookupType.CANDIDATE_STATUS, new LookupInfo(candidateStatusRepository, CandidateStatusBO.class));
        lookupMap.put(LookupType.SJD_STATUS, new LookupInfo(sjdStatusRepository, SjdStatusBO.class));
        lookupMap.put(LookupType.CANDIDATE_EVENT_TYPE, new LookupInfo(candidateEventTypesRepository, CandidateEventBO.class));
        lookupMap.put(LookupType.SJD_EVENT_TYPE, new LookupInfo(sjdEventTypesRepository, SjdEventBO.class));
        lookupMap.put(LookupType.CLIENT, new LookupInfo(clientRepository, ClientBO.class));
        lookupMap.put(LookupType.ANSWER_TYPE, new LookupInfo(answerTypeRepository, AnswerTypeBO.class));
        lookupMap.put(LookupType.QUESTIONNAIRE_TYPE, new LookupInfo(questionnaireTypeRepository, QuestionnaireTypeBO.class));
    }

    @Override
    @Cacheable(cacheNames = "lookup", key = "#type", unless = "#result.size == 0")
    public <T, I> List<LookupDto> getLookupValues(LookupType type) {
        LookupInfo<CrudRepository, Class> lookupInfo = lookupMap.get(type);

        List<LookupDto> result = new ArrayList<>();
        if (lookupInfo.getRepo() != null) {
            CrudRepository<T, I> repo = (CrudRepository<T, I>) lookupInfo.getRepo();
            Iterable<T> itr = repo.findAll();
            result = StreamSupport.stream(itr.spliterator(), false)
                    .map(obj -> mapper.map(obj, LookupDto.class))
                    .toList();
        }
        return result;
    }

    @Override
    @CacheEvict(key = "#type", cacheNames = "lookup")
    public void clearCache(LookupType type) {
        // Empty method to clear cache. No implementation required.
    }

    @Override
    public List<LookupDto> getSkills() {
        List<SkillBO> skills = skillsRepository.findAllByOrderByNameAsc();
        return skills.stream().map(s -> mapper.map(s, LookupDto.class)).collect(Collectors.toList());
    }

    @Override
    public <T, I> List<LookupDto> saveLookupData(List<LookupDto> lookupData, LookupType type) {
        LookupInfo<CrudRepository, Class> lookupInfo = lookupMap.get(type);
        CrudRepository<T, I> repo = (CrudRepository<T, I>) lookupInfo.getRepo();
        Class<T> destClass = (Class<T>) lookupInfo.getLookupClass();

        Iterable<T> result = repo.saveAll(lookupData.stream().map(s -> mapper.map(s, destClass)).collect(Collectors.toList()));
        return StreamSupport
                .stream(result.spliterator(), false)
                .map(s -> mapper.map(s, LookupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<SkillBO> saveAllSkills(List<LookupDto> lookupData) {

        Iterable<SkillBO> skills = skillsRepository.saveAll(
                lookupData
                        .stream()
                        .map(s -> mapper.map(s, SkillBO.class))
                        .collect(Collectors.toList())
        );
        return StreamSupport.stream(skills.spliterator(), false).collect(Collectors.toList());
    }

    @Override
    public <T, I> void deleteLookup(String type, Integer id) {
        if (LookupType.isLookup(type)) {
            LookupInfo<CrudRepository, Class> lookupInfo = lookupMap.get(LookupType.get(type));
            CrudRepository<T, I> repo = (CrudRepository<T, I>) lookupInfo.getRepo();
            repo.deleteById((I) id);
        } else {
            skillsRepository.deleteById(id);
        }
    }
}
