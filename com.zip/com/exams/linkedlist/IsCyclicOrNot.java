package com.exams.linkedlist;

public class IsCyclicOrNot {

	public static void main(String[] args) {

		Node head = new Node(3);
		head.next = new Node(2);
		head.next.next = new Node(0);
		head.next.next.next = new Node(-4);
		head.next.next.next.next = head.next;
		System.out.println(isCyclicOrNot(head));
	}

	private static boolean isCyclicOrNot(Node head) {
		if (head == null || head.next == null) {
			return false;
		}
		Node fpntr = head;
		Node spntr = head;
		while (fpntr != null && spntr.next != null) {
			fpntr = fpntr.next.next;
			spntr = spntr.next;
			if (fpntr == spntr) {
				return true;
			}
		}
		return false;
	}

}
