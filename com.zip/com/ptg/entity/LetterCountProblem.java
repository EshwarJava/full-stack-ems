package com.ptg.entity;

public class LetterCountProblem {

	public static void main(String[] args) {
		// keep this function call here

		System.out.print(LetterCountI("Today, is the greatest day ever!"));

	}

	private static String LetterCountI(String str) {

		String[] strArr = str.split(" ");
		String word = strArr[0];

		int count = 0;
		int temp = 0;
		for (int i = 0; i < strArr.length; i++) {
			for (int j = 0; j < strArr[i].length(); j++) {
				temp = 0;
				for (int k = 0; k < strArr[i].length(); k++) {
					if (strArr[i].charAt(j) == strArr[i].charAt(k)) {
						temp++;
					}
				}
				System.out.println(temp);
				if (count < temp) {
					count = temp;
					word = strArr[i];
					temp = 0;
				}
			}
		}
		if (count == 1) {
			return "-1";
		}
		str = word;
		return str;
	}

}
