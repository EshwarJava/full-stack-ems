package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.OperationsBO;
import org.springframework.data.repository.CrudRepository;

public interface OperationsRepository extends CrudRepository<OperationsBO, Integer> {
}
