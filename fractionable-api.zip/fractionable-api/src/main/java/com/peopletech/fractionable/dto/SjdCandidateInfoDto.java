package com.peopletech.fractionable.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SjdCandidateInfoDto {
    private Integer sjdId;
    private String sjdName;
    private Integer candidateId;
    private Integer candidateStatusId;
    private Float qcRating;
    private Float profilerRating;
    private Boolean auditResult;
    private String auditComments;
    private UserDetailsDto auditBy;
    private Date auditOn;
}
