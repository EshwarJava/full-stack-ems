package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Data
@Table(name = "sjd_events")
public class SjdEventBO {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sjd_events_id_generator")
    @SequenceGenerator(name = "sjd_events_id_generator", sequenceName = "sjd_events_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "sjd_id")
    private Integer sjdId;

    @OneToOne
    @JoinColumn(name = "event_type_id", referencedColumnName = "id")
    private SjdEventTypeBO eventType;

    @Column(name = "description")
    private String description;

    @OneToOne
    @JoinColumn(name = "created_by_id", referencedColumnName = "id")
    private UserDetailsBO createdBy;

    @Column(name = "created_on")
    private Date createdOn;
}
