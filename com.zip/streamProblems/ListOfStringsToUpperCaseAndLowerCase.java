package streamProblems;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ListOfStringsToUpperCaseAndLowerCase {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("bDJKGljh", "vKJUuj", "hjkgbuFUY");
		List<String> lowerCaseList = list.stream().map(String::toLowerCase).collect(Collectors.toList());
		List<String> upperCaseList = list.stream().map(String::toUpperCase).collect(Collectors.toList());
		System.out.println(lowerCaseList);
		System.out.println(upperCaseList);
	}
}
