package com.peopletech.fractionable.entity.compoundkey;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class SjdQuestionnaireID {

    @Column(name = "sjd_id")
    private Integer sjdId;

    @Column(name = "questionnaire_id")
    private Integer questionnaireId;
}
