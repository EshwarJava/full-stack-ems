package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum SjdStatusType {
    DRAFT("Draft"),
    NEW("New"),
    IN_PROGRESS("In Progress"),
    ON_HOLD("On Hold"),
    COMPLETED("Completed");

    private final String type;

    SjdStatusType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public static SjdStatusType get(String type) {
        return Arrays.stream(SjdStatusType.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Candidate status is invalid"));
    }

}
