package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user_companies_lookup")
public class CompanyBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_companies_lookup_id_generator")
    @SequenceGenerator(name = "user_companies_lookup_id_generator", sequenceName = "user_companies_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
