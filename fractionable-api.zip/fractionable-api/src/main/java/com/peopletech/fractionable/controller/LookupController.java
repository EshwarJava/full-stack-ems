package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.service.LookupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

@RestController
@RequestMapping("/lookup")
public class LookupController {

    @Autowired
    private LookupService lookupService;

    @GetMapping("/{type}")
    public Map<String, List<LookupDto>> getLookup(@PathVariable("type") String type) {
        Map<String, List<LookupDto>> result = new HashMap<>();
        if ("all".equalsIgnoreCase(type)) {
            Stream
                    .of(LookupType.values())
                    .forEach(lookup ->
                            result.put(lookup.getType(), lookupService.getLookupValues(lookup))
                    );
        } else {
            result.put(type, lookupService.getLookupValues(LookupType.get(type)));
        }
        return result;
    }

    @GetMapping("/skills/list")
    public List<LookupDto> getSkills() {
        return lookupService.getSkills();
    }

    @PostMapping("/skills")
    public AppResponseDto saveSkills(@RequestBody List<LookupDto> skills) {
        List<String> allSkills = lookupService.getSkills().stream().map(s -> s.getName().toLowerCase()).toList();

        List<LookupDto> lookupData = skills.stream().filter(s -> !allSkills.contains(s.getName().toLowerCase())).toList();
        if (lookupData.size() > 0) {
            lookupService.saveAllSkills(
                    lookupData
            );
        }
        return new AppResponseDto(null, "New skills added successfully");
    }

    @PostMapping("/{type}")
    public List<LookupDto> saveLookupData(@RequestBody List<LookupDto> lookupData, @PathVariable("type") String type) {
        List<LookupDto> response = lookupService.saveLookupData(lookupData, LookupType.get(type));
        lookupService.clearCache(LookupType.get(type));
        return response;
    }

    @DeleteMapping("/skills/{id}")
    public AppResponseDto deleteSkills(@PathVariable("id") Integer id) {
        lookupService.deleteLookup("skills", id);
        return new AppResponseDto(null, "Skill deleted successfully");
    }

    @DeleteMapping("/{type}/{id}")
    public AppResponseDto deleteLookupData(@PathVariable("type") String type, @PathVariable("id") Integer id) {
        lookupService.deleteLookup(type, id);
        lookupService.clearCache(LookupType.get(type));
        return new AppResponseDto(null, "Data deleted successfully");
    }

}
