package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.entity.SjdEventBO;
import com.peopletech.fractionable.entity.SjdEventTypeBO;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.repository.SjdEventRepository;
import com.peopletech.fractionable.service.SjdEventService;
import com.peopletech.fractionable.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class SjdEventServiceImpl implements SjdEventService {

    @Autowired
    SjdEventRepository sjdEventRepository;

    @Autowired
    CommonUtil commonUtil;

    @Override
    @Async
    public void addEvent(Integer sjdId, Integer userId, String eventType, String description) {
        SjdEventBO sjdEventBO = new SjdEventBO();
        sjdEventBO.setSjdId(sjdId);
        sjdEventBO.setCreatedOn(new Date());
        sjdEventBO.setCreatedBy(UserDetailsBO.builder().id(userId).build());
        SjdEventTypeBO sjdEventTypeBO = new SjdEventTypeBO();
        sjdEventTypeBO.setId(commonUtil.getSjdEventTypeId(eventType));
        sjdEventBO.setEventType(sjdEventTypeBO);
        sjdEventBO.setDescription(description);
        sjdEventRepository.save(sjdEventBO);
    }

    @Override
    public List<SjdEventBO> getEventsForSjd(Integer sjdId) {
        return sjdEventRepository.findBySjdIdOrderByCreatedOnDesc(sjdId);
    }
}
