package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.RoleBO;
import com.peopletech.fractionable.entity.UserDetailsBO;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface UserDetailsRepository extends CrudRepository<UserDetailsBO, Integer> {
    Optional<UserDetailsBO> findByEmployeeCode(String employeeCode);

    Optional<UserDetailsBO> findByEmailIgnoreCase(String email);

    List<UserDetailsBO> findAllByActiveOrderByFirstNameAsc(boolean active);

    List<UserDetailsBO> findByRolesAndActive(RoleBO roleBO, Boolean active);

    @Query(value = "select ud.id, CONCAT(ud.first_name, ' ', ud.last_name) as name from user_details ud where ud.id in ?1", nativeQuery = true)
    List<Tuple> getUserNameFromId(List<Integer> userId);
}
