package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SjdBO;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SjdRepository extends CrudRepository<SjdBO, Integer> {

    @Query(value = "select ssl.name as status, count(s.id)  from sjd s inner join sjd_status_lookup ssl on s.status_id = ssl.id where s.id in ?1 group by ssl.name", nativeQuery = true)
    List<Tuple> getSjdCountByStatus(List<Integer> sjdId);

    @Query(value = "select s.id from sjd s where s.is_active = true", nativeQuery = true)
    List<Tuple> findAllSjdId();

}
