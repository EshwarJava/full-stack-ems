package com.peopletech.fractionable.dto.request;

import lombok.Data;

@Data
public class CandidateRejectOrCallbackRequest {
    private Integer sjdId;
    private Integer candidateId;
    private String reason;
    private String comment;
    private String type;
}