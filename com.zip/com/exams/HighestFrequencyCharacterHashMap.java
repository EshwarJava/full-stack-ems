package com.exams;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class HighestFrequencyCharacterHashMap {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();

		HashMap<Character, Integer> map = new HashMap();
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (map.containsKey(ch)) {
				int j = map.get(ch);
				int nc = j + 1;
				map.put(ch, nc);
			} else {
				map.put(ch, 1);
			}
		}
		char mfc = s.charAt(0);
		Set<Character> charSet = map.keySet();
		for (Character character : charSet) {
			if (map.get(character) > map.get(mfc)) {
				mfc = character;
			}
		}
		System.out.println(mfc);

	}

}
