package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public class QCRatedCandidatesReportDto {
    Integer candidateId;
    String candidateName;
    Integer sjdId;
    String sjdName;
    Float qcRating;
    Integer recruiterId;
    String recruiterName;
}
