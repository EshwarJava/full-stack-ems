package com.exams;

public class ContainsDuplicate220 {

	public static void main(String[] args) {
		int[] arr = new int[] { 1, 5, 9, 1, 5, 9};
		int indexDiff = 2;
		int valDiff = 3;
		System.out.println(containsNearbyDuplicate(arr, indexDiff, valDiff));

	}

	private static boolean containsNearbyDuplicate(int[] arr, int indexDiff, int valDiff) {
		
		for(int i = 0; i< arr.length-1; i++) {
			for(int j = i+1; j<arr.length; j++) {
				if(Math.abs(i-j) <= indexDiff) {
					if(Math.abs(arr[i]-arr[j])<=valDiff) {
						return true;
					}
				}
			}
		}
		return false;
	}

}
