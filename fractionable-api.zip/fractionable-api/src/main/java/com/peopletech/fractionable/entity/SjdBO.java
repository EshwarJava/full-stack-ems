package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(name = "sjd")
public class SjdBO {
    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sjd_id_generator")
    @SequenceGenerator(name = "sjd_id_generator", sequenceName = "sjd_id_seq", allocationSize = 1)
    private Integer id;

    private String name;
    private String description;

    @OneToOne
    @JoinColumn(name = "domain_id", referencedColumnName = "id")
    private DomainBO domain;

    @Column(name = "job_location")
    private String jobLocation;

    @Column(name = "end_date")
    private Date endDate;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "sjd_id", referencedColumnName = "id")
    private List<SjdSkillMappingBO> skills;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "sjd_questionnaire_mapping",
            joinColumns = @JoinColumn(
                    name = "sjd_id", referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "questionnaire_id", referencedColumnName = "id"
            )
    )
    private List<QuestionnaireBO> questionnaire = new ArrayList<>();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "sjd_user_mapping",
            joinColumns = @JoinColumn(
                    name = "sjd_id", referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "user_id", referencedColumnName = "id"
            )
    )
    private List<UserDetailsBO> hiringTeam = new ArrayList<>();

    @Column(name = "new_open_positions")
    private Integer newOpenPositions;

    @Column(name = "backfill_open_positions")
    private Integer backfillOpenPositions;

    @OneToOne
    @JoinColumn(name = "job_type_id", referencedColumnName = "id")
    private JobTypeBO jobType;

    @ManyToMany
    @JoinTable(
            name = "sjd_source_channel_mapping",
            joinColumns = @JoinColumn(
                    name = "sjd_id", referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "source_channel_id", referencedColumnName = "id"
            )
    )
    private List<SourceChannelBO> sourcingChannels = new ArrayList<>();

    @OneToOne
    @JoinColumn(name = "priority_id", referencedColumnName = "id")
    private PriorityBO priority;

    @OneToOne
    @JoinColumn(name = "pay_type_id", referencedColumnName = "id")
    private PayTypeBO payType;

    @Column(name = "pay_rate")
    private Integer payRate;

    @Column(name = "project_duration")
    private Integer projectDuration;

    @Column(name = "is_Visa")
    private Boolean isVisa;

    @Column(name = "visa_type")
    private String visaType;

    @Column(name = "experience_level")
    private Integer experienceLevel;

    @Column(name = "max_experience")
    private Integer maxExperience;

    private String keywords;

    @Column(name = "target_companies")
    private String targetCompanies;


    @Column(name = "evaluation_criteria")
    private String evaluationCriteria;

    @OneToOne
    @JoinColumn(name = "qualification_id", referencedColumnName = "id")
    private QualificationBO qualification;

    @OneToOne
    @JoinColumn(name = "client_id", referencedColumnName = "id")
    private ClientBO client;

    @Column(name = "notice_period")
    private Integer noticePeriod;

    @Column(name = "is_client_round")
    private Boolean isClientRound;

    @Column(name = "no_of_tech_interview")
    private Integer noOfTechnicalInterview;

    @Column(name = "is_online_test")
    private Boolean isOnlineTest;

    @OneToOne
    @JoinColumn(name = "status_id", referencedColumnName = "id")
    private SjdStatusBO sjdStatus;

    @OneToOne
    @JoinColumn(name = "created_by_id", referencedColumnName = "id")
    private UserDetailsBO createdBy;

    @Column(name = "created_on")
    private Date createdOn;

    @Column(name = "modified_by_id")
    private Integer modifiedById;

    @Column(name = "modified_on")
    private Date modifiedOn;

    @OneToOne
    @JoinColumn(name = "operation_id", referencedColumnName = "id")
    private OperationsBO operation;

    @Column(name = "is_active")
    private Boolean active;

    @Column(name = "hiring_manager")
    private String hiringManager;

    @Column(name = "is_migrated")
    private Boolean isMigrated;

    @Column(name="publish")
    private Boolean publish;
}
