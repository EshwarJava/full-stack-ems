package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.service.MyTeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/team")
public class MyTeamController {

    @Autowired
    MyTeamService myTeamService;

    @GetMapping
    public List<UserDetailsDto> getMyTeam(@RequestHeader Integer userId) {

        return myTeamService.getMyTeam(userId);
    }

    @PostMapping
    public AppResponseDto<List<Integer>> addMyTeam(@RequestHeader Integer userId, @RequestBody List<Integer> memberList) {
        myTeamService.addMyTeam(memberList, userId);
        return new AppResponseDto<>(memberList, "team added successfully");
    }

    @DeleteMapping
    public AppResponseDto<Integer> deleteMyTeam(@RequestHeader Integer userId, @RequestParam Integer memberId) {
        myTeamService.removeFromMyTeam(memberId, userId);
        return new AppResponseDto<>(memberId, "team member deleted successfully");
    }
}
