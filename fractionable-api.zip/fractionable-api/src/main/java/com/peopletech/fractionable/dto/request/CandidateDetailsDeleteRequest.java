package com.peopletech.fractionable.dto.request;

import lombok.Data;

@Data
public class CandidateDetailsDeleteRequest {
    private Integer sjdId;
    private Integer candidateId;
    private Integer idToBeDeleted;
}
