package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum RejectReasons {
    LOW_RATING("Low Rating"),
    MISSED_INTERVIEW("Did not show up for interview"),
    FAILED_IN_INTERVIEW("Failed in an interview"),
    DOCUMENTS_NOT_VALID("Documents not valid"),
    OTHERS("Other");

    private final String type;

    RejectReasons(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public static RejectReasons get(String type) {
        return Arrays.stream(RejectReasons.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Reject Reason is invalid"));
    }
}
