package com.ptg.userdepartmentservice.dto;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DepartmentUpdateDTO {
    String name;
}
