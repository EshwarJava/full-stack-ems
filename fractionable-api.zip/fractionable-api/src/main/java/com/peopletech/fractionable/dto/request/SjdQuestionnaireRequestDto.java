package com.peopletech.fractionable.dto.request;

import lombok.Data;

@Data
public class SjdQuestionnaireRequestDto {
    private Integer sjdId;
    private Integer questionnaireId;
}
