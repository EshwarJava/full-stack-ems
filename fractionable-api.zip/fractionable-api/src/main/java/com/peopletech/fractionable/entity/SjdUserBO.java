package com.peopletech.fractionable.entity;

import com.peopletech.fractionable.entity.compoundkey.SjdUserID;
import jakarta.persistence.*;
import lombok.Data;

@Entity(name = "sjd_user_mapping")
@IdClass(SjdUserID.class)
@Data
public class SjdUserBO {

    @Id
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sjd_id", referencedColumnName = "id")
    private SjdBO sjd;
    @Column(name = "user_id")
    @Id
    private Integer userId;
}
