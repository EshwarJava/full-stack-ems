package com.ptg.userdepartmentservice.service;

import com.ptg.userdepartmentservice.dto.UserWithDepartmentDTO;
import com.ptg.userdepartmentservice.entity.UserBO;

import java.util.List;


public interface UserService {

    UserBO addUser(UserWithDepartmentDTO userWithDepartmentDTO);

    List<UserBO> getAllUserDetails();

    UserBO getUserAndDepartmentDetails(Integer userId);

    List<UserBO> listOfUsersOfDepartment(Integer deptId);

    String deleteUser(Integer userId);
}
