package com.peopletech.fractionable.entity.compoundkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class SjdUserID implements Serializable {
    private Integer sjd;
    private Integer userId;
}
