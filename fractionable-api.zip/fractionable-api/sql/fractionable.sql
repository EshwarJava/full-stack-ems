DROP TABLE IF EXISTS public.questionnaire_answers;
DROP TABLE IF EXISTS public.candidate_events;
DROP TABLE IF EXISTS public.candidate_comments;
DROP TABLE IF EXISTS public.candidate_interview;
DROP TABLE IF EXISTS public.sjd_candidate_info;
DROP TABLE IF EXISTS public.candidate_documents;
DROP TABLE IF EXISTS public.candidate_certification;
DROP TABLE IF EXISTS public.candidate_education;
DROP TABLE IF EXISTS public.candidate_employment;
DROP TABLE IF EXISTS public.candidate_skills_mapping;
DROP TABLE IF EXISTS public.candidate;
DROP TABLE IF EXISTS public.sjd_events;
DROP TABLE IF EXISTS public.sjd_questionnaire_mapping;
DROP TABLE IF EXISTS public.sjd_skills_mapping;
DROP TABLE IF EXISTS public.sjd_source_channel_mapping;
DROP TABLE IF EXISTS public.sjd_user_mapping;
DROP TABLE IF EXISTS public.sjd;
DROP TABLE IF EXISTS public.questionnaire_skills_mapping;
DROP TABLE IF EXISTS public.questionnaire_question_mapping;
DROP TABLE IF EXISTS public.questionnaire;
DROP TABLE IF EXISTS public.questions;
DROP TABLE IF EXISTS public.user_lead_mapping;
DROP TABLE IF EXISTS public.user_role_mapping;
DROP TABLE IF EXISTS public.user_credentials;
DROP TABLE IF EXISTS public.user_details;
DROP TABLE IF EXISTS public.sjd_event_types_lookup;
DROP TABLE IF EXISTS public.candidate_event_types_lookup;
DROP TABLE IF EXISTS public.sjd_status_lookup;
DROP TABLE IF EXISTS public.candidate_status_lookup;
DROP TABLE IF EXISTS public.source_channel_lookup;
DROP TABLE IF EXISTS public.skills_lookup;
DROP TABLE IF EXISTS public.user_roles_lookup;
DROP TABLE IF EXISTS public.user_operations_lookup;
DROP TABLE IF EXISTS public.user_departments_lookup;
DROP TABLE IF EXISTS public.user_companies_lookup;
DROP TABLE IF EXISTS public.domain_lookup;
DROP TABLE IF EXISTS public.job_type_lookup;
DROP TABLE IF EXISTS public.client_lookup;
DROP TABLE IF EXISTS public.pay_type_lookup;
DROP TABLE IF EXISTS public.priorities_lookup;
DROP TABLE IF EXISTS public.qualification_lookup;
DROP TABLE IF EXISTS public.questionnaire_type_lookup;
DROP TABLE IF EXISTS public.answer_type_lookup;

CREATE TABLE IF NOT EXISTS public.answer_type_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT answer_type_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.questionnaire_type_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT questionnaire_type_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.qualification_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT qualification_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.priorities_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT priorities_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.pay_type_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT pay_type_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.client_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT client_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.job_type_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT job_type_lookup_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.domain_lookup
(
    id serial,
    name character varying NOT NULL,
    CONSTRAINT domain_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.user_companies_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT user_company_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.user_departments_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT user_department_pk PRIMARY KEY (id)
);


CREATE TABLE IF NOT EXISTS public.user_operations_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT user_operations_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.user_roles_lookup
(
    id serial,
    name character varying(500) NOT NULL,
    CONSTRAINT user_roles_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.skills_lookup
(
    id serial,
    name character varying(100) NOT NULL,
    CONSTRAINT skills_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.source_channel_lookup
(
    id serial,
    name character varying(100),
    CONSTRAINT source_channel_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.candidate_status_lookup
(
    id serial,
    name character varying(100) NOT NULL,
    CONSTRAINT candidate_status_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.sjd_status_lookup
(
    id serial,
    name character varying(100) NOT NULL,
    CONSTRAINT sjd_status_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.candidate_event_types_lookup
(
    id serial,
    name character varying(100) NOT NULL,
    CONSTRAINT candidate_event_types_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.sjd_event_types_lookup
(
    id serial,
    name character varying(100) NOT NULL,
    CONSTRAINT sjd_event_types_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.user_details
(
    id serial,
    employee_code character varying(20),
    first_name character varying(500) NOT NULL,
    last_name character varying(500) NOT NULL,
    email character varying(200),
    phone_number character varying(20),
    company_id integer NOT NULL,
    department_id integer NOT NULL,
    operation_id integer NOT NULL,
    is_active boolean NOT NULL,
    is_locked boolean NOT NULL,
    created_by integer,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    modified_by integer,
    modified_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT user_details_pk PRIMARY KEY (id),
    CONSTRAINT user_details_email_uk UNIQUE (email)
);

ALTER TABLE IF EXISTS public.user_details
    ADD CONSTRAINT user_details_companies_fk FOREIGN KEY (company_id)
    REFERENCES public.user_companies_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.user_details
    ADD CONSTRAINT user_details_departments_fk FOREIGN KEY (department_id)
    REFERENCES public.user_departments_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.user_details
    ADD CONSTRAINT user_details_operations_fk FOREIGN KEY (operation_id)
    REFERENCES public.user_operations_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.user_credentials
(
    id serial,
    user_id integer NOT NULL,
    username character varying(200) NOT NULL,
    password character varying(500) NOT NULL,
    modified_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT user_credentials_pk PRIMARY KEY (id),
    CONSTRAINT user_credentials_uk UNIQUE (username)
);

ALTER TABLE IF EXISTS public.user_credentials
    ADD CONSTRAINT user_credentials_userid_fk FOREIGN KEY (user_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.user_role_mapping
(
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    CONSTRAINT user_role_mapping_pk PRIMARY KEY (user_id, role_id)
);

ALTER TABLE IF EXISTS public.user_role_mapping
    ADD CONSTRAINT user_role_user_id_fk FOREIGN KEY (user_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.user_role_mapping
    ADD CONSTRAINT user_role_role_id_fk FOREIGN KEY (role_id)
    REFERENCES public.user_roles_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.user_lead_mapping
(
    user_id integer NOT NULL,
    lead_id integer NOT NULL,
    CONSTRAINT user_lead_mapping_pkey PRIMARY KEY (user_id, lead_id),
    CONSTRAINT lead_id_fk FOREIGN KEY (lead_id)
        REFERENCES public.user_details (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT user_id_fk FOREIGN KEY (user_id)
        REFERENCES public.user_details (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.questions (
    id serial,
    question character varying(200) NOT NULL,
    answer_type_id integer,
    required boolean,
    CONSTRAINT questions_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.questions
    ADD CONSTRAINT question_answer_type_fk FOREIGN KEY (answer_type_id)
    REFERENCES public.answer_type_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.questionnaire (
    id serial,
    name character varying(100) NOT NULL,
    questionnaire_type_id integer,
    created_by_id integer,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT questionnaire_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.questionnaire
    ADD CONSTRAINT questionnaire_type_fk FOREIGN KEY (questionnaire_type_id)
    REFERENCES public.questionnaire_type_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.questionnaire
    ADD CONSTRAINT questionnaire_created_by_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.questionnaire_question_mapping
(
    questionnaire_id integer NOT NULL,
    question_id integer NOT NULL,
    CONSTRAINT questionnaire_question_mapping_pk PRIMARY KEY (questionnaire_id, question_id)
);

ALTER TABLE IF EXISTS public.questionnaire_question_mapping
    ADD CONSTRAINT questionnaire_id_fk FOREIGN KEY (questionnaire_id)
    REFERENCES public.questionnaire (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.questionnaire_question_mapping
    ADD CONSTRAINT question_id_fk FOREIGN KEY (question_id)
    REFERENCES public.questions (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.questionnaire_skills_mapping
(
    questionnaire_id integer NOT NULL,
    skill_id integer NOT NULL,
    CONSTRAINT questionnaire_skills_mapping_pk PRIMARY KEY (questionnaire_id, skill_id)
);

ALTER TABLE IF EXISTS public.questionnaire_skills_mapping
    ADD CONSTRAINT questionnaire_skill_id_fk FOREIGN KEY (questionnaire_id)
    REFERENCES public.questionnaire (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.questionnaire_skills_mapping
    ADD CONSTRAINT questionnaire_skill_skill_id_fk FOREIGN KEY (skill_id)
    REFERENCES public.skills_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd
(
    id serial,
    name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    description character varying(5000) COLLATE pg_catalog."default",
    domain_id integer,
    priority_id integer,
    job_location character varying(100) COLLATE pg_catalog."default",
    end_date date,
    operation_id integer,
    client_id integer,
    new_open_positions integer,
    backfill_open_positions integer DEFAULT 0,
    job_type_id integer,
    pay_type_id integer,
    pay_rate integer,
    hiring_manager character varying(200),
    project_duration integer,
    is_visa boolean,
    visa_type character varying(100) COLLATE pg_catalog."default",
    experience_level integer,
    max_experience integer,
    keywords character varying(5000) COLLATE pg_catalog."default",
    target_companies character varying(10000) COLLATE pg_catalog."default",
    evaluation_criteria character varying(200) COLLATE pg_catalog."default",
    qualification_id integer,
    notice_period integer,
    is_client_round boolean,
    no_of_tech_interview smallint,
    is_online_test boolean,
    status_id integer,
    is_active boolean NOT NULL DEFAULT true,
    created_by_id integer,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    modified_by_id integer,
    modified_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    publish boolean,
    CONSTRAINT sjd_pkey PRIMARY KEY (id)

);

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT domain_fk FOREIGN KEY (domain_id)
    REFERENCES public.domain_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT client_fk FOREIGN KEY (client_id)
    REFERENCES public.client_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT qualification_fk FOREIGN KEY (qualification_id)
    REFERENCES public.qualification_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT job_type FOREIGN KEY (job_type_id)
    REFERENCES public.job_type_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT pay_type FOREIGN KEY (pay_type_id)
    REFERENCES public.pay_type_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT priority_fk FOREIGN KEY (priority_id)
    REFERENCES public.priorities_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT status_fk FOREIGN KEY (status_id)
    REFERENCES public.sjd_status_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT operations_fk FOREIGN KEY (operation_id)
    REFERENCES public.user_operations_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT created_by_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd
    ADD CONSTRAINT modified_by_fk FOREIGN KEY (modified_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd_user_mapping
(
    sjd_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT sjd_team_mapping_pkey PRIMARY KEY (sjd_id, user_id)
);

ALTER TABLE IF EXISTS public.sjd_user_mapping
    ADD CONSTRAINT sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_user_mapping
    ADD CONSTRAINT team_fk FOREIGN KEY (user_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd_source_channel_mapping
(
    sjd_id integer NOT NULL,
    source_channel_id integer NOT NULL,
    CONSTRAINT sjd_source_channel_mapping_pkey PRIMARY KEY (sjd_id, source_channel_id)
);

ALTER TABLE IF EXISTS public.sjd_source_channel_mapping
    ADD CONSTRAINT sc_fk FOREIGN KEY (source_channel_id)
    REFERENCES public.source_channel_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_source_channel_mapping
    ADD CONSTRAINT sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd_skills_mapping
(
    sjd_id integer NOT NULL,
    skill_id integer NOT NULL,
    min_experience numeric(3, 1),
    CONSTRAINT sjd_skills_mapping_pkey PRIMARY KEY (sjd_id, skill_id)
);

ALTER TABLE IF EXISTS public.sjd_skills_mapping
    ADD CONSTRAINT sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_skills_mapping
    ADD CONSTRAINT skill_fk FOREIGN KEY (skill_id)
    REFERENCES public.skills_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd_questionnaire_mapping
(
    sjd_id integer NOT NULL,
    questionnaire_id integer NOT NULL,
    CONSTRAINT sjd_questionnaire_mapping_pk PRIMARY KEY (sjd_id, questionnaire_id)
);

ALTER TABLE IF EXISTS public.sjd_questionnaire_mapping
    ADD CONSTRAINT sjd_questionnaire_mapping_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_questionnaire_mapping
    ADD CONSTRAINT sjd_questionnaire_fk FOREIGN KEY (questionnaire_id)
    REFERENCES public.questionnaire (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd_events
(
    id serial,
    sjd_id integer NOT NULL,
    event_type_id integer NOT NULL,
    description character varying(500),
    created_by_id integer NOT NULL,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT sjd_events_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.sjd_events
    ADD CONSTRAINT sjd_events_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_events
    ADD CONSTRAINT sjd_events_type_fk FOREIGN KEY (event_type_id)
    REFERENCES public.sjd_event_types_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_events
    ADD CONSTRAINT sjd_events_created_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate
(
    id serial,
    name character varying(300) NOT NULL,
    email character varying(300),
    phone_number character varying(200),
    location character varying(500),
    notice_period_days integer,
    experience numeric(3, 1),
    resume_id character varying(100),
    source_channel_id integer,
    domain_expertise_id integer,
    present_role character varying(300),
    current_ctc character varying(50),
    expected_ctc character varying(50),
    linkedin_url character varying(1000),
    visa_type character varying(1000),
    visa_status character varying(1000),
    visa_validity character varying(1000),
    additional_info  character varying(10000),
    operations_id integer,
    expected_ctc_frequency integer,
    current_ctc_frequency integer,
    created_by_id integer NOT NULL,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    modified_by_id integer NOT NULL,
    modified_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    ai_checkbox boolean,
    CONSTRAINT candidate_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT candidate_created_by_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT candidate_modified_by_fk FOREIGN KEY (modified_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT source_portal_fk FOREIGN KEY (source_channel_id)
    REFERENCES public.source_channel_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT domain_fk FOREIGN KEY (domain_expertise_id)
    REFERENCES public.domain_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT operations_fk FOREIGN KEY (operations_id)
    REFERENCES public.user_operations_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT current_ctc_frequency_fk FOREIGN KEY (current_ctc_frequency)
    REFERENCES public.pay_type_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate
    ADD CONSTRAINT expected_ctc_frequency_fk FOREIGN KEY (expected_ctc_frequency)
    REFERENCES public.pay_type_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_skills_mapping
(
    candidate_id integer,
    skill_id integer,
    CONSTRAINT candidate_skill_mapping_pk PRIMARY KEY (candidate_id, skill_id)
);

ALTER TABLE IF EXISTS public.candidate_skills_mapping
    ADD CONSTRAINT candidate_skill_mapping_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_skills_mapping
    ADD CONSTRAINT candidate_skill_mapping_skill_fk FOREIGN KEY (skill_id)
    REFERENCES public.skills_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_employment
(
    id serial,
    candidate_id integer,
    company_name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    designation character varying(100),
    start_date date,
    end_date date,
    responsibilities character varying(5000) COLLATE pg_catalog."default",
    location character varying(200) COLLATE pg_catalog."default",
    CONSTRAINT candidate_employment_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_employment
    ADD CONSTRAINT candidate_employment_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_education
(
    id serial,
    candidate_id integer,
    institution_name character varying(500) COLLATE pg_catalog."default" NOT NULL,
    location character varying(200) COLLATE pg_catalog."default",
    qualification character varying(200) COLLATE pg_catalog."default",
    domain character varying(200) COLLATE pg_catalog."default",
    start_date date,
    end_date date,
    CONSTRAINT candidate_education_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_education
    ADD CONSTRAINT candidate_education_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_certification

(
    id serial,
    candidate_id integer,
    certification_name character varying(1000) COLLATE pg_catalog."default" NOT NULL,
    issued_by character varying(1000) COLLATE pg_catalog."default",
    certification_year integer,
    CONSTRAINT candidate_certification_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_certification
    ADD CONSTRAINT candidate_certification_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


CREATE TABLE IF NOT EXISTS public.candidate_documents(
    id serial,
    candidate_id integer,
    document_name character varying(200),
    file_name character varying(200),
    document_url character varying(1000),
    created_by_id integer,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT candidate_documents_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_documents
    ADD CONSTRAINT candidate_documents_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_documents
    ADD CONSTRAINT candidate_documents_created_by_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.sjd_candidate_info
(
    sjd_id integer,
    candidate_id integer,
    candidate_status_id integer,
    qc_rating numeric(2, 1),
    profiler_rating numeric(2, 1),
    audit_result boolean,
    audit_comments character varying(10000),
    audit_by_id integer,
    audit_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by_id integer,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT sjd_candidate_info_pk UNIQUE (sjd_id, candidate_id)
);

ALTER TABLE IF EXISTS public.sjd_candidate_info
    ADD CONSTRAINT sjd_candidate_info_sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_candidate_info
    ADD CONSTRAINT sjd_candidate_info_candidate_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_candidate_info
    ADD CONSTRAINT sjd_candidate_info_status_fk FOREIGN KEY (candidate_status_id)
    REFERENCES public.candidate_status_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_candidate_info
    ADD CONSTRAINT sjd_candidate_info_audit_by_fk FOREIGN KEY (audit_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.sjd_candidate_info
    ADD CONSTRAINT sjd_candidate_info_created_by_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_interview
(
    id serial,
    sjd_id integer,
    candidate_id integer,
    evaluator_id integer,
    interview_level character varying(100),
    start_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    interview_feedback character varying(1000),
    interview_recording_link  character varying(500),
    is_recommended boolean,
    created_by_id integer,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    modified_by_id integer,
    modified_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT candidate_interview_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_interview
    ADD CONSTRAINT candidate_interview_sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_interview
    ADD CONSTRAINT candidate_interview_candidate_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_interview
    ADD CONSTRAINT candidate_interview_evaluator_fk FOREIGN KEY (evaluator_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_interview
    ADD CONSTRAINT candidate_interview_created_by_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_interview
    ADD CONSTRAINT candidate_interview_modified_by_fk FOREIGN KEY (modified_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_comments
(
    id serial,
    sjd_id integer,
    candidate_id integer,
    comments character varying(500) NOT NULL,
    created_by_id integer NOT NULL,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT candidate_comments_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_comments
    ADD CONSTRAINT candidate_comments_sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_comments
    ADD CONSTRAINT candidate_comments_candidate_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_comments
    ADD CONSTRAINT candidate_comments_created_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.candidate_events
(
    id serial,
    sjd_id integer NOT NULL,
    candidate_id integer NOT NULL,
    event_type_id integer NOT NULL,
    description character varying(500),
    created_by_id integer NOT NULL,
    created_on TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT candidate_events_pk PRIMARY KEY (id)
);

ALTER TABLE IF EXISTS public.candidate_events
    ADD CONSTRAINT candidate_events_sjd_fk FOREIGN KEY (sjd_id)
    REFERENCES public.sjd (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_events
    ADD CONSTRAINT candidate_events_fk FOREIGN KEY (candidate_id)
    REFERENCES public.candidate (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_events
    ADD CONSTRAINT candidate_events_type_fk FOREIGN KEY (event_type_id)
    REFERENCES public.candidate_event_types_lookup (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

ALTER TABLE IF EXISTS public.candidate_events
    ADD CONSTRAINT candidate_events_created_fk FOREIGN KEY (created_by_id)
    REFERENCES public.user_details (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

CREATE TABLE IF NOT EXISTS public.questionnaire_answers
(
    id serial,
    sjd_id integer NOT NULL,
    questionnaire_id integer NOT NULL,
    question_id integer NOT NULL,
    candidate_id integer NOT NULL,
    answer character varying COLLATE pg_catalog."default",
    CONSTRAINT questionnaire_answer_pkey PRIMARY KEY (id),
    CONSTRAINT candidate_fk FOREIGN KEY (candidate_id)
        REFERENCES public.candidate (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT question_fk FOREIGN KEY (question_id)
        REFERENCES public.questions (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT questionnaire_fk FOREIGN KEY (questionnaire_id)
        REFERENCES public.questionnaire (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT sjd_fk FOREIGN KEY (sjd_id)
        REFERENCES public.sjd (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)