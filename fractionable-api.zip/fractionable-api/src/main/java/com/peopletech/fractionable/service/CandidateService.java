package com.peopletech.fractionable.service;

import com.peopletech.fractionable.constants.CandidateDetailsType;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.CandidateDetailsDeleteRequest;
import com.peopletech.fractionable.dto.request.CandidateRejectOrCallbackRequest;

import java.util.List;

public interface CandidateService {

    List<CandidateDto> getAllCandidates();

    CandidateDto getCandidateById(Integer candidateId, Integer sjdId);

    List<CandidateDto> getCandidateBySjdId(Integer candidateId);

    Integer saveCandidate(CandidateDto candidate, Integer sjdId, Integer userId);

    Integer updateCandidate(CandidateDto candidate, Integer sjdId, Integer userId, Boolean isResumeUpdate);

    void updateCandidateStatus(CandidateStatusChangeDto request, Integer userId);

    void updateCandidateQcRating(SjdCandidateInfoDto request, Integer userId);

    void updateCandidateProfilerRating(SjdCandidateInfoDto request, Integer userId);

    Integer addComments(CandidateEventDto request, Integer userId);

    void rejectOrCallback(CandidateRejectOrCallbackRequest request, Integer userId);

    void scheduleInterview(CandidateInterviewDto candidateInterviewDto, Integer userId);

    void updateInterviewDetails(CandidateInterviewDto candidateInterviewDto, Integer userId, Boolean isFeedback);

    Integer addDocumentInformation(CandidateDocumentDto document, Integer userId);

    List<CandidateDto> searchCandidate(String email, String phone);

    void auditCandidate(SjdCandidateInfoDto info, Integer userId);

    List<ResumeSearchResponseDto> searchCandidateFromResumeId(List<String> resumeIds);

    void deleteCandidateDetails(CandidateDetailsDeleteRequest id, CandidateDetailsType type, Integer userId);
}
