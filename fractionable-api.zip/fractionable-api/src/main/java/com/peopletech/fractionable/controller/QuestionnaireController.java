package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.QuestionDto;
import com.peopletech.fractionable.dto.QuestionnaireAnswerDto;
import com.peopletech.fractionable.dto.QuestionnaireDto;
import com.peopletech.fractionable.dto.request.GetQuestionRequestDto;
import com.peopletech.fractionable.dto.request.SjdQuestionnaireRequestDto;
import com.peopletech.fractionable.service.QuestionnaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/questionnaire")
public class QuestionnaireController {

    @Autowired
    private QuestionnaireService questionnaireService;

    @GetMapping
    public List<QuestionnaireDto> getAllQuestionnaire() {
        return questionnaireService.getAllQuestionnaire();
    }

    @GetMapping("/{id}")
    public QuestionnaireDto getQuestionnaireById(@PathVariable("id") Integer id) {
        return questionnaireService.getQuestionnaireById(id);
    }

    @PostMapping
    public AppResponseDto<Integer> saveQuestionnaire(@RequestBody QuestionnaireDto questionnaire, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        Integer id = questionnaireService.saveQuestionnaire(questionnaire, userId);
        return new AppResponseDto<>(id, "Questionnaire created successfully");
    }

    @PatchMapping
    public AppResponseDto<Integer> updateQuestionnaire(@RequestBody QuestionnaireDto questionnaire, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        Integer id = questionnaireService.updateQuestionnaire(questionnaire, userId);
        return new AppResponseDto<>(id, "Questionnaire created successfully");
    }

    @PostMapping("/question")
    public AppResponseDto<Integer> saveQuestion(@RequestBody QuestionDto question) {
        Integer id = questionnaireService.saveQuestion(question);
        return new AppResponseDto<>(id, "Question created successfully");
    }

    @DeleteMapping("/question/{id}")
    public AppResponseDto deleteQuestion(@PathVariable("id") Integer id) {
        questionnaireService.deleteQuestion(id);
        return new AppResponseDto(null, "Question deleted successfully");
    }

    @PostMapping("/question/type")
    public Set<QuestionDto> getQuestionsByQuestionnaireId(@RequestBody GetQuestionRequestDto request) {
        List<QuestionnaireDto> questionnaire = questionnaireService.getAllQuestionnaireByType(request.getQuestionnaireType(), request.getSkills());

        return questionnaire
                .stream()
                .map(QuestionnaireDto::getQuestions)
                .flatMap(List::stream)
                .collect(Collectors.toSet());
    }

    @PostMapping("/sjd")
    public AppResponseDto tagQuestionnaireToSjd(@RequestBody SjdQuestionnaireRequestDto request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        questionnaireService.tagQuestionnaireToSjd(request, userId);
        return new AppResponseDto(null, "Questionnaire tagged to SJD");
    }

    @GetMapping("/answer")
    public List<QuestionnaireAnswerDto> getQuestionnaireAnswers(@RequestParam Integer sjdId, @RequestParam Integer candidateId) {
        return questionnaireService.getQuestionnaireAnswers(sjdId, candidateId);
    }

    @PutMapping("/answer")
    public AppResponseDto<Integer> saveQuestionnaireAnswers(@RequestBody List<QuestionnaireAnswerDto> data, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        questionnaireService.saveQuestionnaireAnswers(data, userId);
        return new AppResponseDto<>(null, "Questionnaire answer saved successfully");
    }
}
