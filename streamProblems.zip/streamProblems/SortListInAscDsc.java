package streamProblems;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortListInAscDsc {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("bcJKGljh", "vKJUuj", "bcdj", "hjkgbuFUY");
		List<String> ascList  = list.stream().sorted().collect(Collectors.toList());
		System.out.println(ascList);
		List<String> desList  = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(desList);
	}

}
