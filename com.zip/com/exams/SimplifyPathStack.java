package com.exams;

import java.util.Stack;

public class SimplifyPathStack {

	public static void main(String[] args) {
		String str = "/home//foo/";
		System.out.println(simplefiedPath(str));
	}

	private static String simplefiedPath(String str) {
		StringBuilder sb = new StringBuilder(str);
		if(sb.charAt(sb.length()-1) == '/') {
			sb.deleteCharAt(sb.length()-1);
		}
		if(sb.charAt(0) != '/') {
		sb.insert(0, '/');
		}
		
		StringBuilder res = new StringBuilder();
		
		Stack<Character> st = new Stack<>();
		for (char ch : sb.toString().toCharArray()) {
			st.push(ch);	
		}
		System.out.println(st.size());
		
		while(!st.isEmpty()) {
			
			if(st.peek() != '/') {
				res.append(st.pop());
			}
			else {
				
				st.pop();
			}	
		}
		return res.toString();
	}

}
